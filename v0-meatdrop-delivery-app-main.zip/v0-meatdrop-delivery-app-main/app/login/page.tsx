"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Beef, Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  // Update the handleLogin function to always succeed
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      // Simulate authentication delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Always succeed for development purposes
      localStorage.setItem(
        "meatdrop-auth",
        JSON.stringify({
          isLoggedIn: true,
          user: { email: email || "admin@meatdrop.com", role: "admin" },
          timestamp: new Date().toISOString(),
        }),
      )

      // Redirect to dashboard
      router.push("/dashboard")
    } catch (error) {
      setError("An error occurred during login. Please try again.")
      console.error("Login error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4">
            <Beef className="h-12 w-12 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold">MeatDrop Admin</CardTitle>
          <CardDescription className="text-gray-700">Enter your credentials to access the dashboard</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Update the form to use the onSubmit handler properly */}
          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-2">
              <Label htmlFor="email" className="text-gray-700">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="admin@meatdrop.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-gray-700">
                  Password
                </Label>
                <Button
                  variant="link"
                  className="px-0 font-normal text-xs text-primary h-auto"
                  type="button"
                  onClick={() => router.push("/forgot-password")}
                >
                  Forgot password?
                </Button>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-500" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-500" />
                  )}
                  <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
                </Button>
              </div>
            </div>
            <Button className="w-full" type="submit" disabled={isLoading}>
              {isLoading ? "Signing in..." : "Sign In"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-center w-full">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or</span>
              </div>
            </div>
          </div>
          <div className="text-center text-sm">
            <span className="text-gray-600">Are you a butchery looking to join MeatDrop?</span>
            <Button
              variant="link"
              className="font-normal text-primary h-auto"
              type="button"
              onClick={() => router.push("/signup")}
            >
              Register your business
            </Button>
          </div>
        </CardFooter>
        <div className="px-8 pb-8 text-center">
          <div className="mt-4 p-3 bg-gray-50 border rounded-md">
            <p className="font-medium text-gray-800 mb-1">Demo Credentials:</p>
            <p className="text-primary font-medium">Email: admin@meatdrop.com</p>
            <p className="text-primary font-medium">Password: password123</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
