import type React from "react"
import "@/app/globals.css"
import { Inter } from "next/font/google"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import { ThemeProvider } from "@/components/theme-provider"
import { MeatdropProvider } from "@/components/meatdrop-provider"
import { AuthProvider } from "@/components/auth-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "MeatDrop - Butchery Management System",
  description: "Manage your butchery deliveries, inventory, and orders",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Add this code to redirect from login to dashboard
  if (typeof window !== "undefined") {
    if (window.location.pathname === "/login") {
      window.location.href = "/"
    }
  }

  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <AuthProvider>
            <MeatdropProvider>
              <div className="flex min-h-screen flex-col">
                <header className="sticky top-0 z-40 border-b bg-background">
                  <div className="container flex h-16 items-center justify-between py-4">
                    <MainNav />
                    <UserNav />
                  </div>
                </header>
                <main className="flex-1 container py-6">{children}</main>
              </div>
            </MeatdropProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
