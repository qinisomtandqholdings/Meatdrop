import Link from "next/link"
import { Beef, ChevronRight, ClipboardList, Package, ShoppingCart, Truck, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { RecentOrders } from "@/components/recent-orders"
import { InventoryOverview } from "@/components/inventory-overview"
import { DeliveryMap } from "@/components/delivery-map"

export default function DashboardPage() {
  return (
    <>
      <DashboardShell>
        <DashboardHeader heading="Dashboard" text="Overview of your MeatDrop business">
          <div className="flex items-center gap-2">
            <Button asChild>
              <Link href="/inventory/add">
                <Package className="mr-2 h-4 w-4" />
                Add Inventory
              </Link>
            </Button>
          </div>
        </DashboardHeader>
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
            <TabsTrigger value="deliveries">Deliveries</TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">142</div>
                  <p className="text-xs text-gray-600">+12% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending Deliveries</CardTitle>
                  <Truck className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">8</div>
                  <p className="text-xs text-gray-600">3 scheduled for today</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Low Stock Items</CardTitle>
                  <ClipboardList className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">4</div>
                  <p className="text-xs text-gray-600">Beef ribeye, pork belly, lamb chops</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Customers</CardTitle>
                  <Users className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">573</div>
                  <p className="text-xs text-gray-600">+18% from last month</p>
                </CardContent>
              </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Recent Orders</CardTitle>
                  <CardDescription className="text-gray-700">You have received 12 orders today</CardDescription>
                </CardHeader>
                <CardContent>
                  <RecentOrders />
                </CardContent>
              </Card>
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Delivery Map</CardTitle>
                  <CardDescription className="text-gray-700">Current deliveries in progress</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px] relative">
                  <DeliveryMap />
                </CardContent>
              </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Inventory Overview</CardTitle>
                  <CardDescription className="text-gray-700">Current stock levels and alerts</CardDescription>
                </CardHeader>
                <CardContent>
                  <InventoryOverview />
                </CardContent>
              </Card>
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                  <CardDescription className="text-gray-700">Common tasks and operations</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-2">
                  <Button variant="outline" className="justify-between w-full" asChild>
                    <Link href="/inventory">
                      <span className="flex items-center">
                        <Beef className="mr-2 h-4 w-4 text-primary" />
                        Update Inventory
                      </span>
                      <ChevronRight className="h-4 w-4" />
                    </Link>
                  </Button>
                  <Button variant="outline" className="justify-between w-full" asChild>
                    <Link href="/reports">
                      <span className="flex items-center">
                        <ClipboardList className="mr-2 h-4 w-4 text-primary" />
                        Generate Reports
                      </span>
                      <ChevronRight className="h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="orders" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Order Management</CardTitle>
                <CardDescription className="text-gray-700">View and manage all customer orders</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-800">The full order management interface will be displayed here.</p>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="inventory" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Inventory Management</CardTitle>
                <CardDescription className="text-gray-700">Track and manage your meat inventory</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-800">The full inventory management interface will be displayed here.</p>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="deliveries" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Delivery Management</CardTitle>
                <CardDescription className="text-gray-700">Track and manage all deliveries</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-800">The full delivery management interface will be displayed here.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DashboardShell>
    </>
  )
}
