"use client"

import { useState, useEffect } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle, Filter, History, Package, Plus, RefreshCw, Search, TrendingDown, TrendingUp } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useMeatdrop } from "@/components/notifications"

// Initial inventory data
const initialInventory = [
  {
    id: 1,
    name: "Ribeye Steak",
    category: "Beef",
    stock: 15,
    maxStock: 100,
    price: 29.99,
    status: "Low",
    history: [
      { date: "2023-06-15", type: "restock", amount: 10, note: "Weekly delivery" },
      { date: "2023-06-14", type: "order", amount: -5, note: "Order #ORD-1234" },
      { date: "2023-06-10", type: "restock", amount: 20, note: "Initial stock" },
    ],
  },
  {
    id: 2,
    name: "Pork Belly",
    category: "Pork",
    stock: 8,
    maxStock: 50,
    price: 18.5,
    status: "Low",
    history: [
      { date: "2023-06-13", type: "restock", amount: 5, note: "Emergency restock" },
      { date: "2023-06-12", type: "order", amount: -7, note: "Order #ORD-1230" },
      { date: "2023-06-08", type: "restock", amount: 15, note: "Weekly delivery" },
    ],
  },
  {
    id: 3,
    name: "Chicken Breast",
    category: "Poultry",
    stock: 45,
    maxStock: 80,
    price: 12.99,
    status: "Good",
    history: [
      { date: "2023-06-14", type: "order", amount: -5, note: "Order #ORD-1233" },
      { date: "2023-06-10", type: "restock", amount: 30, note: "Weekly delivery" },
      { date: "2023-06-05", type: "restock", amount: 25, note: "Initial stock" },
    ],
  },
  {
    id: 4,
    name: "Lamb Chops",
    category: "Lamb",
    stock: 12,
    maxStock: 40,
    price: 32.75,
    status: "Low",
    history: [
      { date: "2023-06-15", type: "order", amount: -3, note: "Order #ORD-1235" },
      { date: "2023-06-12", type: "restock", amount: 10, note: "Weekly delivery" },
      { date: "2023-06-07", type: "restock", amount: 15, note: "Initial stock" },
    ],
  },
  {
    id: 5,
    name: "Ground Beef",
    category: "Beef",
    stock: 60,
    maxStock: 100,
    price: 14.99,
    status: "Good",
    history: [
      { date: "2023-06-14", type: "restock", amount: 20, note: "Weekly delivery" },
      { date: "2023-06-10", type: "order", amount: -10, note: "Order #ORD-1231" },
      { date: "2023-06-05", type: "restock", amount: 50, note: "Initial stock" },
    ],
  },
  {
    id: 6,
    name: "Pork Sausages",
    category: "Pork",
    stock: 35,
    maxStock: 60,
    price: 16.5,
    status: "Good",
    history: [
      { date: "2023-06-13", type: "order", amount: -5, note: "Order #ORD-1232" },
      { date: "2023-06-09", type: "restock", amount: 25, note: "Weekly delivery" },
      { date: "2023-06-04", type: "restock", amount: 20, note: "Initial stock" },
    ],
  },
  {
    id: 7,
    name: "T-Bone Steak",
    category: "Beef",
    stock: 25,
    maxStock: 70,
    price: 34.99,
    status: "Good",
    history: [
      { date: "2023-06-15", type: "order", amount: -2, note: "Order #ORD-1236" },
      { date: "2023-06-11", type: "restock", amount: 15, note: "Weekly delivery" },
      { date: "2023-06-06", type: "restock", amount: 20, note: "Initial stock" },
    ],
  },
  {
    id: 8,
    name: "Beef Brisket",
    category: "Beef",
    stock: 18,
    maxStock: 50,
    price: 22.99,
    status: "Good",
    history: [
      { date: "2023-06-14", type: "order", amount: -2, note: "Order #ORD-1234" },
      { date: "2023-06-10", type: "restock", amount: 10, note: "Weekly delivery" },
      { date: "2023-06-05", type: "restock", amount: 15, note: "Initial stock" },
    ],
  },
]

export default function InventoryPage() {
  const { inventoryUpdates, clearInventoryUpdate } = useMeatdrop()
  const [inventory, setInventory] = useState(initialInventory)

  // Load inventory from localStorage on initial load
  useEffect(() => {
    const savedInventory = localStorage.getItem("meatdrop-inventory")
    if (savedInventory) {
      try {
        setInventory(JSON.parse(savedInventory))
      } catch (e) {
        console.error("Failed to parse saved inventory", e)
      }
    }
  }, [])

  // Save inventory to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("meatdrop-inventory", JSON.stringify(inventory))
  }, [inventory])

  const [searchTerm, setSearchTerm] = useState("")
  const [addProductOpen, setAddProductOpen] = useState(false)
  const [updateStockOpen, setUpdateStockOpen] = useState(false)
  const [historyOpen, setHistoryOpen] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<any>(null)
  const [recentlyUpdated, setRecentlyUpdated] = useState<number[]>([])

  // Form states for adding new product
  const [newProduct, setNewProduct] = useState({
    name: "",
    category: "Beef",
    stock: 0,
    maxStock: 100,
    price: 0,
    description: "",
    supplier: "",
    batchNumber: "",
  })

  // Form state for updating stock
  const [stockUpdate, setStockUpdate] = useState({
    amount: 0,
    note: "",
  })

  // Process inventory updates from orders
  useEffect(() => {
    if (inventoryUpdates.length > 0) {
      const updatedIds: number[] = []

      const newInventory = [...inventory]

      inventoryUpdates.forEach((update) => {
        const productIndex = newInventory.findIndex((p) => p.id === update.productId)

        if (productIndex !== -1) {
          // Update the stock
          const product = newInventory[productIndex]
          const newStock = product.stock + update.change
          const newStatus = newStock / product.maxStock < 0.25 ? "Low" : "Good"

          // Add to history
          const historyEntry = {
            date: new Date().toISOString().split("T")[0],
            type: "order",
            amount: update.change,
            note: `Order processed at ${new Date().toLocaleTimeString()}`,
          }

          newInventory[productIndex] = {
            ...product,
            stock: newStock,
            status: newStatus,
            history: [historyEntry, ...product.history],
          }

          updatedIds.push(update.productId)

          // Clear this update since we've processed it
          clearInventoryUpdate(update.productId)
        }
      })

      // Update inventory and highlight updated rows
      setInventory(newInventory)
      setRecentlyUpdated(updatedIds)

      // Clear highlights after 5 seconds
      if (updatedIds.length > 0) {
        setTimeout(() => {
          setRecentlyUpdated([])
        }, 5000)
      }
    }
  }, [inventoryUpdates, inventory, clearInventoryUpdate])

  // Filter inventory based on search term
  const filteredInventory = inventory.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Handle adding a new product
  const handleAddProduct = () => {
    const newId = Math.max(...inventory.map((p) => p.id)) + 1
    const status = newProduct.stock / newProduct.maxStock < 0.25 ? "Low" : "Good"

    const productToAdd = {
      id: newId,
      name: newProduct.name,
      category: newProduct.category,
      stock: newProduct.stock,
      maxStock: newProduct.maxStock,
      price: newProduct.price,
      status,
      history: [
        {
          date: new Date().toISOString().split("T")[0],
          type: "restock",
          amount: newProduct.stock,
          note: "Initial stock",
        },
      ],
    }

    setInventory([...inventory, productToAdd])
    setAddProductOpen(false)

    // Reset form
    setNewProduct({
      name: "",
      category: "Beef",
      stock: 0,
      maxStock: 100,
      price: 0,
      description: "",
      supplier: "",
      batchNumber: "",
    })
  }

  // Handle updating stock
  const handleUpdateStock = () => {
    if (!selectedProduct) return

    const updatedInventory = inventory.map((product) => {
      if (product.id === selectedProduct.id) {
        // Calculate new stock level
        const newStock = product.stock + stockUpdate.amount

        // Determine new status
        const newStatus = newStock / product.maxStock < 0.25 ? "Low" : "Good"

        // Add to history
        const historyEntry = {
          date: new Date().toISOString().split("T")[0],
          type: "restock",
          amount: stockUpdate.amount,
          note: stockUpdate.note || "Restock",
        }

        return {
          ...product,
          stock: newStock,
          status: newStatus,
          history: [historyEntry, ...product.history],
        }
      }
      return product
    })

    setInventory(updatedInventory)
    setUpdateStockOpen(false)

    // Highlight the updated row
    setRecentlyUpdated([selectedProduct.id])

    // Clear highlight after 5 seconds
    setTimeout(() => {
      setRecentlyUpdated([])
    }, 5000)

    // We're still tracking the stock update, but without the popup notification
    console.log(`Stock updated: Added ${stockUpdate.amount}kg to ${selectedProduct.name}`)

    // Reset form
    setStockUpdate({
      amount: 0,
      note: "",
    })
  }

  // Open update stock dialog
  const openUpdateStock = (product: any) => {
    setSelectedProduct(product)
    setUpdateStockOpen(true)
  }

  // Open history sheet
  const openHistory = (product: any) => {
    setSelectedProduct(product)
    setHistoryOpen(true)
  }

  // Calculate maximum amount that can be added without exceeding 100%
  const getMaxAddAmount = (product: any) => {
    if (!product) return 0
    return product.maxStock - product.stock
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Inventory" text="Manage your meat inventory">
        <Button onClick={() => setAddProductOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Product
        </Button>
      </DashboardHeader>
      <div className="space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search inventory..."
                className="pl-8 w-[300px]"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-black">Product</TableHead>
                <TableHead className="text-black">Category</TableHead>
                <TableHead className="text-black">Current Stock</TableHead>
                <TableHead className="text-black">Stock Level</TableHead>
                <TableHead className="text-black">Price/kg</TableHead>
                <TableHead className="text-black">Status</TableHead>
                <TableHead className="text-right text-black">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInventory.map((product) => (
                <TableRow
                  key={product.id}
                  className={recentlyUpdated.includes(product.id) ? "bg-yellow-50 transition-colors duration-500" : ""}
                >
                  <TableCell className="font-medium text-black">{product.name}</TableCell>
                  <TableCell className="text-black">{product.category}</TableCell>
                  <TableCell className={`text-black ${recentlyUpdated.includes(product.id) ? "font-bold" : ""}`}>
                    {product.stock} kg
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={(product.stock / product.maxStock) * 100} className="h-2 w-[100px]" />
                      <span className="text-xs text-black">
                        {Math.round((product.stock / product.maxStock) * 100)}%
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-black">R{product.price.toFixed(2)}</TableCell>
                  <TableCell>
                    <Badge
                      variant={product.status === "Low" ? "destructive" : "default"}
                      className={product.status === "Good" ? "bg-green-700 hover:bg-green-800" : ""}
                    >
                      {product.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex items-center gap-1 border-primary text-primary hover:bg-primary hover:text-white"
                        onClick={() => openUpdateStock(product)}
                      >
                        <RefreshCw className="h-3.5 w-3.5" />
                        <span>Update</span>
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex items-center gap-1 border-primary text-primary hover:bg-primary hover:text-white"
                        onClick={() => openHistory(product)}
                      >
                        <History className="h-3.5 w-3.5" />
                        <span>History</span>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Add Product Dialog */}
      <Dialog open={addProductOpen} onOpenChange={setAddProductOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add New Product</DialogTitle>
            <DialogDescription className="text-black">
              Enter the details of the new meat product to add to your inventory.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-black">
                  Product Name
                </Label>
                <Input
                  id="name"
                  placeholder="e.g. Ribeye Steak"
                  value={newProduct.name}
                  onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category" className="text-black">
                  Category
                </Label>
                <Select
                  value={newProduct.category}
                  onValueChange={(value) => setNewProduct({ ...newProduct, category: value })}
                >
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Beef">Beef</SelectItem>
                    <SelectItem value="Pork">Pork</SelectItem>
                    <SelectItem value="Poultry">Poultry</SelectItem>
                    <SelectItem value="Lamb">Lamb</SelectItem>
                    <SelectItem value="Game">Game</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="stock" className="text-black">
                  Initial Stock (kg)
                </Label>
                <Input
                  id="stock"
                  type="number"
                  min="0"
                  step="0.1"
                  placeholder="0.0"
                  value={newProduct.stock || ""}
                  onChange={(e) => setNewProduct({ ...newProduct, stock: Number.parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="price" className="text-black">
                  Price per kg (R)
                </Label>
                <Input
                  id="price"
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="0.00"
                  value={newProduct.price || ""}
                  onChange={(e) => setNewProduct({ ...newProduct, price: Number.parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="maxStock" className="text-black">
                  Max Stock Level (kg)
                </Label>
                <Input
                  id="maxStock"
                  type="number"
                  min="0"
                  step="0.1"
                  placeholder="0.0"
                  value={newProduct.maxStock || ""}
                  onChange={(e) => setNewProduct({ ...newProduct, maxStock: Number.parseFloat(e.target.value) || 0 })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-black">
                Description
              </Label>
              <Textarea
                id="description"
                placeholder="Describe the product, including cut, grade, and any special characteristics"
                rows={2}
                value={newProduct.description}
                onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="supplier" className="text-black">
                  Supplier
                </Label>
                <Input
                  id="supplier"
                  placeholder="Supplier name"
                  value={newProduct.supplier}
                  onChange={(e) => setNewProduct({ ...newProduct, supplier: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="batch" className="text-black">
                  Batch/Lot Number
                </Label>
                <Input
                  id="batch"
                  placeholder="For traceability"
                  value={newProduct.batchNumber}
                  onChange={(e) => setNewProduct({ ...newProduct, batchNumber: e.target.value })}
                />
              </div>
            </div>
          </div>
          <DialogFooter className="sticky bottom-0 pt-2 bg-background">
            <Button variant="outline" onClick={() => setAddProductOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleAddProduct}
              disabled={!newProduct.name || newProduct.stock <= 0 || newProduct.price <= 0}
            >
              <Package className="mr-2 h-4 w-4" />
              Add to Inventory
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Update Stock Dialog */}
      <Dialog open={updateStockOpen} onOpenChange={setUpdateStockOpen}>
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Restock Inventory</DialogTitle>
            <DialogDescription className="text-black">
              {selectedProduct && `Add stock for ${selectedProduct.name}`}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label className="text-black">Current Stock</Label>
              <div className="rounded-md bg-muted p-2 text-black">{selectedProduct?.stock} kg</div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount" className="text-black">
                Amount to Add (kg)
              </Label>
              <div className="flex items-center">
                <TrendingUp className="mr-2 h-4 w-4 text-green-600" />
                <Input
                  id="amount"
                  type="number"
                  min={0}
                  max={selectedProduct ? getMaxAddAmount(selectedProduct) : 0}
                  step="0.1"
                  placeholder="0.0"
                  value={stockUpdate.amount || ""}
                  onChange={(e) => {
                    const value = Number.parseFloat(e.target.value) || 0
                    setStockUpdate({ ...stockUpdate, amount: value })
                  }}
                />
              </div>
              {selectedProduct && (
                <div className="text-xs text-muted-foreground">
                  Maximum: {getMaxAddAmount(selectedProduct).toFixed(1)} kg (to reach 100% capacity)
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="note" className="text-black">
                Note
              </Label>
              <Textarea
                id="note"
                placeholder="e.g. Weekly delivery, Special order, etc."
                value={stockUpdate.note}
                onChange={(e) => setStockUpdate({ ...stockUpdate, note: e.target.value })}
              />
            </div>

            <div className="rounded-md bg-muted p-3">
              <div className="text-sm font-medium text-black">New Stock Level</div>
              <div className="mt-1 text-lg font-bold text-black">
                {selectedProduct && (selectedProduct.stock + stockUpdate.amount).toFixed(1)} kg
              </div>
              <div className="mt-1 text-sm text-black">
                {selectedProduct && (
                  <>
                    {Math.round(((selectedProduct.stock + stockUpdate.amount) / selectedProduct.maxStock) * 100)}% of
                    maximum capacity ({selectedProduct.maxStock} kg)
                  </>
                )}
              </div>
              {selectedProduct && selectedProduct.stock + stockUpdate.amount > selectedProduct.maxStock && (
                <Alert className="mt-2 bg-yellow-50 border-yellow-200">
                  <AlertCircle className="h-4 w-4 text-yellow-600" />
                  <AlertDescription className="text-yellow-700">
                    Warning: This will exceed the maximum capacity of {selectedProduct.maxStock} kg.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </div>
          <DialogFooter className="sticky bottom-0 pt-2 bg-background">
            <Button variant="outline" onClick={() => setUpdateStockOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleUpdateStock}
              disabled={
                stockUpdate.amount <= 0 ||
                (selectedProduct && selectedProduct.stock + stockUpdate.amount > selectedProduct.maxStock)
              }
            >
              <TrendingUp className="mr-2 h-4 w-4" />
              Confirm Restock
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Product History Sheet */}
      <Sheet open={historyOpen} onOpenChange={setHistoryOpen}>
        <SheetContent className="sm:max-w-[600px] overflow-y-auto">
          <SheetHeader>
            <SheetTitle>Product History</SheetTitle>
            <SheetDescription className="text-black">
              {selectedProduct && `Stock history for ${selectedProduct.name}`}
            </SheetDescription>
          </SheetHeader>
          <div className="mt-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium text-black">{selectedProduct?.name}</h3>
                <p className="text-sm text-black">{selectedProduct?.category}</p>
              </div>
              <Badge
                variant={selectedProduct?.status === "Low" ? "destructive" : "default"}
                className={selectedProduct?.status === "Good" ? "bg-green-700 hover:bg-green-800" : ""}
              >
                {selectedProduct?.status}
              </Badge>
            </div>

            <div className="rounded-md bg-muted p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-muted-foreground">Current Stock</div>
                  <div className="text-lg font-bold text-black">{selectedProduct?.stock} kg</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Price per kg</div>
                  <div className="text-lg font-bold text-black">R{selectedProduct?.price.toFixed(2)}</div>
                </div>
              </div>
            </div>

            <div>
              <h4 className="mb-4 text-sm font-medium text-black">Stock History</h4>

              <Tabs defaultValue="all" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="restock">Restocks</TabsTrigger>
                  <TabsTrigger value="order">Orders</TabsTrigger>
                </TabsList>

                <TabsContent value="all" className="mt-4 space-y-4">
                  {selectedProduct?.history.map((entry: any, index: number) => (
                    <div key={index} className="flex items-center gap-3 rounded-md border p-3">
                      <div
                        className={`rounded-full p-2 ${
                          entry.type === "restock"
                            ? "bg-green-100 text-green-600"
                            : entry.type === "order"
                              ? "bg-red-100 text-red-600"
                              : "bg-blue-100 text-blue-600"
                        }`}
                      >
                        {entry.type === "restock" && <TrendingUp className="h-4 w-4" />}
                        {entry.type === "order" && <TrendingDown className="h-4 w-4" />}
                        {entry.type === "adjustment" && <RefreshCw className="h-4 w-4" />}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-black">
                            {entry.type === "restock" ? "Restock" : entry.type === "order" ? "Order" : "Adjustment"}
                          </span>
                          <span className="text-sm text-muted-foreground">{entry.date}</span>
                        </div>
                        <div className="mt-1 text-sm text-black">{entry.note}</div>
                      </div>
                      <div className={`text-lg font-bold ${entry.amount > 0 ? "text-green-600" : "text-red-600"}`}>
                        {entry.amount > 0 ? "+" : ""}
                        {entry.amount} kg
                      </div>
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="restock" className="mt-4 space-y-4">
                  {selectedProduct?.history
                    .filter((entry: any) => entry.type === "restock")
                    .map((entry: any, index: number) => (
                      <div key={index} className="flex items-center gap-3 rounded-md border p-3">
                        <div className="rounded-full bg-green-100 p-2 text-green-600">
                          <TrendingUp className="h-4 w-4" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-black">Restock</span>
                            <span className="text-sm text-muted-foreground">{entry.date}</span>
                          </div>
                          <div className="mt-1 text-sm text-black">{entry.note}</div>
                        </div>
                        <div className="text-lg font-bold text-green-600">+{entry.amount} kg</div>
                      </div>
                    ))}
                </TabsContent>

                <TabsContent value="order" className="mt-4 space-y-4">
                  {selectedProduct?.history
                    .filter((entry: any) => entry.type === "order")
                    .map((entry: any, index: number) => (
                      <div key={index} className="flex items-center gap-3 rounded-md border p-3">
                        <div className="rounded-full bg-red-100 p-2 text-red-600">
                          <TrendingDown className="h-4 w-4" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-black">Order</span>
                            <span className="text-sm text-muted-foreground">{entry.date}</span>
                          </div>
                          <div className="mt-1 text-sm text-black">{entry.note}</div>
                        </div>
                        <div className="text-lg font-bold text-red-600">{entry.amount} kg</div>
                      </div>
                    ))}
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </DashboardShell>
  )
}
