"use client"

import type React from "react"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Save } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function AddInventoryPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    name: "",
    category: "Beef",
    stock: "",
    price: "",
    reorderLevel: "",
    description: "",
    storage: "",
    supplier: "",
    batch: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      router.push("/inventory")
    }, 1500)
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Add Inventory" text="Add new products to your inventory">
        <Button variant="outline" asChild>
          <Link href="/inventory">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Inventory
          </Link>
        </Button>
      </DashboardHeader>

      <Card>
        <CardHeader>
          <CardTitle>Product Information</CardTitle>
          <CardDescription className="text-black">Enter the details of the new meat product</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-black">
                  Product Name
                </Label>
                <Input
                  id="name"
                  placeholder="e.g. Ribeye Steak"
                  value={formData.name}
                  onChange={(e) => handleChange("name", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category" className="text-black">
                  Category
                </Label>
                <Select defaultValue={formData.category} onValueChange={(value) => handleChange("category", value)}>
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Beef">Beef</SelectItem>
                    <SelectItem value="Pork">Pork</SelectItem>
                    <SelectItem value="Poultry">Poultry</SelectItem>
                    <SelectItem value="Lamb">Lamb</SelectItem>
                    <SelectItem value="Game">Game</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="stock" className="text-black">
                  Initial Stock (kg)
                </Label>
                <Input
                  id="stock"
                  type="number"
                  min="0"
                  step="0.1"
                  placeholder="0.0"
                  value={formData.stock}
                  onChange={(e) => handleChange("stock", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="price" className="text-black">
                  Price per kg (R)
                </Label>
                <Input
                  id="price"
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="0.00"
                  value={formData.price}
                  onChange={(e) => handleChange("price", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reorder-level" className="text-black">
                  Reorder Level (kg)
                </Label>
                <Input
                  id="reorder-level"
                  type="number"
                  min="0"
                  step="0.1"
                  placeholder="0.0"
                  value={formData.reorderLevel}
                  onChange={(e) => handleChange("reorderLevel", e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-black">
                Description
              </Label>
              <Textarea
                id="description"
                placeholder="Describe the product, including cut, grade, and any special characteristics"
                rows={4}
                value={formData.description}
                onChange={(e) => handleChange("description", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="storage" className="text-black">
                Storage Instructions
              </Label>
              <Textarea
                id="storage"
                placeholder="Specify storage requirements, temperature, shelf life, etc."
                rows={2}
                value={formData.storage}
                onChange={(e) => handleChange("storage", e.target.value)}
              />
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="supplier" className="text-black">
                  Supplier
                </Label>
                <Input
                  id="supplier"
                  placeholder="Supplier name"
                  value={formData.supplier}
                  onChange={(e) => handleChange("supplier", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="batch" className="text-black">
                  Batch/Lot Number
                </Label>
                <Input
                  id="batch"
                  placeholder="For traceability"
                  value={formData.batch}
                  onChange={(e) => handleChange("batch", e.target.value)}
                />
              </div>
            </div>

            <div className="flex justify-end">
              <Button
                type="submit"
                className="w-full md:w-auto"
                disabled={isSubmitting || !formData.name || !formData.stock || !formData.price}
              >
                <Save className="mr-2 h-4 w-4" />
                {isSubmitting ? "Saving..." : "Save Product"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </DashboardShell>
  )
}
