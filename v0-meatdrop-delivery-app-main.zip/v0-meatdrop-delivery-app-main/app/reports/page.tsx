"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { DatePicker } from "@/components/date-picker"
import { InventoryReport } from "@/components/inventory-report"
import { SalesReport } from "@/components/sales-report"
import { DeliveryReport } from "@/components/delivery-report"
import { FileDown, FileText, Printer } from "lucide-react"

export default function ReportsPage() {
  const [reportType, setReportType] = useState("inventory")
  const [dateRange, setDateRange] = useState("last7days")
  const [startDate, setStartDate] = useState<Date | undefined>(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000))
  const [endDate, setEndDate] = useState<Date | undefined>(new Date())
  const [isGenerating, setIsGenerating] = useState(false)
  const [reportGenerated, setReportGenerated] = useState(false)

  const handleGenerateReport = () => {
    setIsGenerating(true)

    // Simulate report generation
    setTimeout(() => {
      setIsGenerating(false)
      setReportGenerated(true)
    }, 1500)
  }

  const handleExportCSV = () => {
    // In a real app, this would generate and download a CSV file
    alert("CSV export functionality would be implemented here")
  }

  const handleExportPDF = () => {
    // In a real app, this would generate and download a PDF file
    alert("PDF export functionality would be implemented here")
  }

  const handlePrint = () => {
    window.print()
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Reports" text="Generate and export business reports">
        <div className="flex gap-2">
          {reportGenerated && (
            <>
              <Button variant="outline" onClick={handleExportCSV}>
                <FileDown className="mr-2 h-4 w-4" />
                Export CSV
              </Button>
              <Button variant="outline" onClick={handleExportPDF}>
                <FileText className="mr-2 h-4 w-4" />
                Export PDF
              </Button>
              <Button variant="outline" onClick={handlePrint}>
                <Printer className="mr-2 h-4 w-4" />
                Print
              </Button>
            </>
          )}
        </div>
      </DashboardHeader>

      <Card>
        <CardHeader>
          <CardTitle>Report Generator</CardTitle>
          <CardDescription className="text-gray-700">Select parameters to generate business reports</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="report-type" className="text-gray-700">
                Report Type
              </Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger id="report-type">
                  <SelectValue placeholder="Select report type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="inventory">Inventory Report</SelectItem>
                  <SelectItem value="sales">Sales Report</SelectItem>
                  <SelectItem value="delivery">Delivery Performance</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date-range" className="text-gray-700">
                Date Range
              </Label>
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger id="date-range">
                  <SelectValue placeholder="Select date range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                  <SelectItem value="last7days">Last 7 Days</SelectItem>
                  <SelectItem value="last30days">Last 30 Days</SelectItem>
                  <SelectItem value="thisMonth">This Month</SelectItem>
                  <SelectItem value="lastMonth">Last Month</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button className="w-full" onClick={handleGenerateReport} disabled={isGenerating}>
                {isGenerating ? "Generating..." : "Generate Report"}
              </Button>
            </div>
          </div>

          {dateRange === "custom" && (
            <div className="grid gap-6 mt-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="text-gray-700">Start Date</Label>
                <DatePicker date={startDate} setDate={setStartDate} />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-700">End Date</Label>
                <DatePicker date={endDate} setDate={setEndDate} />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {reportGenerated && (
        <div className="mt-6">
          <Tabs defaultValue={reportType} value={reportType} onValueChange={setReportType}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="inventory">Inventory Report</TabsTrigger>
              <TabsTrigger value="sales">Sales Report</TabsTrigger>
              <TabsTrigger value="delivery">Delivery Performance</TabsTrigger>
            </TabsList>
            <TabsContent value="inventory" className="mt-4">
              <InventoryReport />
            </TabsContent>
            <TabsContent value="sales" className="mt-4">
              <SalesReport />
            </TabsContent>
            <TabsContent value="delivery" className="mt-4">
              <DeliveryReport />
            </TabsContent>
          </Tabs>
        </div>
      )}
    </DashboardShell>
  )
}
