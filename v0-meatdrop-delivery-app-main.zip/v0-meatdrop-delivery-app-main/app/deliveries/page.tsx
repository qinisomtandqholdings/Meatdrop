"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ExternalLink, Filter, MoreHorizontal, Plus, Search, Truck } from "lucide-react"
import { DeliveryMap } from "@/components/delivery-map"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function DeliveriesPage() {
  const searchParams = useSearchParams()
  const [deliveries, setDeliveries] = useState([
    {
      orderId: "ORD-1234",
      driver: "Alex Johnson",
      customer: "John Smith",
      address: "123 Main St, Anytown",
      status: "In Transit",
      isHighlighted: false,
    },
    {
      orderId: "ORD-1233",
      driver: "Maria Garcia",
      customer: "Sarah Johnson",
      address: "456 Oak Ave, Somewhere",
      status: "Scheduled",
      isHighlighted: false,
    },
    {
      orderId: "ORD-1232",
      driver: "David Lee",
      customer: "Michael Brown",
      address: "789 Pine Rd, Elsewhere",
      status: "In Transit",
      isHighlighted: false,
    },
    {
      orderId: "ORD-1231",
      driver: "Lisa Chen",
      customer: "Emily Davis",
      address: "101 Cedar Ln, Nowhere",
      status: "Delivered",
      isHighlighted: false,
    },
    {
      orderId: "ORD-1230",
      driver: "James Wilson",
      customer: "Robert Wilson",
      address: "202 Maple Dr, Anywhere",
      status: "Scheduled",
      isHighlighted: false,
    },
  ])

  // Check if we're coming from order processing
  useEffect(() => {
    const processedOrderId = searchParams.get("processed")

    if (processedOrderId) {
      // Add the processed order to the top of the list
      const newDelivery = {
        orderId: processedOrderId,
        driver: "Auto-assigned",
        customer: "Recent Customer",
        address: "Customer Address",
        status: "In Transit",
        isHighlighted: true,
      }

      setDeliveries((prev) => [newDelivery, ...prev])

      // Remove highlight after 5 seconds
      const timer = setTimeout(() => {
        setDeliveries((prev) =>
          prev.map((delivery) =>
            delivery.orderId === processedOrderId ? { ...delivery, isHighlighted: false } : delivery,
          ),
        )
      }, 5000)

      return () => clearTimeout(timer)
    }
  }, [searchParams])

  return (
    <DashboardShell>
      <DashboardHeader heading="Deliveries" text="Track and manage deliveries">
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          <span>Schedule Delivery</span>
          <ExternalLink className="ml-2 h-3 w-3" />
        </Button>
      </DashboardHeader>
      <div className="grid gap-4 md:grid-cols-7">
        <div className="space-y-4 md:col-span-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input type="search" placeholder="Search deliveries..." className="pl-8 w-[300px]" />
              </div>
              <Button variant="outline" size="sm">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </div>
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-black">Order ID</TableHead>
                  <TableHead className="text-black">Driver</TableHead>
                  <TableHead className="text-black">Customer</TableHead>
                  <TableHead className="text-black">Address</TableHead>
                  <TableHead className="text-black">Status</TableHead>
                  <TableHead className="text-right text-black">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {deliveries.map((delivery, i) => (
                  <TableRow key={i} className={delivery.isHighlighted ? "bg-yellow-50" : ""}>
                    <TableCell className={`font-medium text-black ${delivery.isHighlighted ? "animate-pulse" : ""}`}>
                      {delivery.orderId}
                    </TableCell>
                    <TableCell className="text-black">{delivery.driver}</TableCell>
                    <TableCell className="text-black">{delivery.customer}</TableCell>
                    <TableCell className="max-w-[150px] truncate text-black">{delivery.address}</TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          delivery.status === "In Transit"
                            ? "default"
                            : delivery.status === "Scheduled"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {delivery.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Open menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>View details</DropdownMenuItem>
                          <DropdownMenuItem>Update status</DropdownMenuItem>
                          <DropdownMenuItem>Contact driver</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
        <div className="md:col-span-3">
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Live Delivery Map</CardTitle>
              <CardDescription className="text-black">Track current deliveries in real-time</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <DeliveryMap />
            </CardContent>
          </Card>
        </div>
      </div>
      <div className="mt-6">
        <Card>
          <CardHeader>
            <CardTitle>Delivery Drivers</CardTitle>
            <CardDescription className="text-black">Manage your delivery team</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              {[
                {
                  name: "Alex Johnson",
                  status: "Active",
                  deliveries: 3,
                  phone: "555-123-4567",
                  proximity: "2.3 km",
                },
                {
                  name: "Maria Garcia",
                  status: "Active",
                  deliveries: 2,
                  phone: "555-234-5678",
                  proximity: "1.1 km",
                },
                {
                  name: "David Lee",
                  status: "Active",
                  deliveries: 1,
                  phone: "555-345-6789",
                  proximity: "5.7 km",
                },
                {
                  name: "Lisa Chen",
                  status: "Inactive",
                  deliveries: 0,
                  phone: "555-456-7890",
                  proximity: "3.2 km",
                },
                {
                  name: "James Wilson",
                  status: "Active",
                  deliveries: 2,
                  phone: "555-567-8901",
                  proximity: "4.5 km",
                },
              ].map((driver, i) => (
                <Card key={i} className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium text-black">{driver.name}</h3>
                      <p className="text-sm text-black">{driver.phone}</p>
                      <p className="text-sm text-black">Current location: {driver.proximity} away</p>
                      <div className="mt-2 flex items-center gap-2">
                        <Badge variant={driver.status === "Active" ? "default" : "outline"}>{driver.status}</Badge>
                        <span className="text-sm text-black">{driver.deliveries} active deliveries</span>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon">
                      <Truck className="h-4 w-4" />
                      <span className="sr-only">View driver</span>
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}
