"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Beef, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function SignupSuccessPage() {
  const router = useRouter()
  const [businessName, setBusinessName] = useState("")

  useEffect(() => {
    // Get registration data from localStorage
    const registrationData = localStorage.getItem("meatdrop-registration")
    if (registrationData) {
      try {
        const data = JSON.parse(registrationData)
        setBusinessName(data.businessName)
      } catch (error) {
        console.error("Error parsing registration data:", error)
      }
    }
  }, [])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <Card className="w-full max-w-md text-center">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-4">
            <CheckCircle2 className="h-16 w-16 text-green-500" />
          </div>
          <CardTitle className="text-2xl font-bold">Registration Successful!</CardTitle>
          <CardDescription className="text-gray-700">
            {businessName ? `${businessName} has been` : "Your butchery has been"} successfully registered with
            MeatDrop.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg bg-green-50 p-4 border border-green-100">
            <p className="text-green-800">
              Our team will review your application and contact you within 1-2 business days to complete the onboarding
              process.
            </p>
          </div>

          <div className="space-y-2 text-left">
            <h3 className="font-medium text-gray-900">What happens next?</h3>
            <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
              <li>Our team will verify your business information</li>
              <li>You'll receive an email with verification instructions</li>
              <li>A MeatDrop representative will contact you to discuss logistics</li>
              <li>Once approved, you'll gain access to the MeatDrop dashboard</li>
            </ul>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <Button className="w-full" onClick={() => router.push("/login")}>
            Go to Login
          </Button>
          <div className="flex items-center justify-center gap-2 mt-4">
            <Beef className="h-5 w-5 text-primary" />
            <span className="text-sm text-gray-600">MeatDrop Butchery Network</span>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
