"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Beef, Building2, MapPin, Mail, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

export default function SignupPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    // Business Information
    businessName: "",
    businessType: "butchery",
    registrationNumber: "",
    yearEstablished: "",

    // Contact Information
    contactName: "",
    email: "",
    phone: "",

    // Address Information
    address: "",
    city: "",
    postalCode: "",

    // Account Information
    password: "",
    confirmPassword: "",

    // Terms and Conditions
    acceptTerms: false,
    acceptMarketing: false,
  })

  const updateFormData = (field: string, value: string | boolean) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const validateStep = (currentStep: number) => {
    setError("")

    if (currentStep === 1) {
      if (!formData.businessName) return "Business name is required"
      if (!formData.registrationNumber) return "Registration number is required"
      if (!formData.yearEstablished) return "Year established is required"
    }

    if (currentStep === 2) {
      if (!formData.contactName) return "Contact name is required"
      if (!formData.email || !formData.email.includes("@")) return "Valid email is required"
      if (!formData.phone) return "Phone number is required"
    }

    if (currentStep === 3) {
      if (!formData.address) return "Address is required"
      if (!formData.city) return "City is required"
      if (!formData.postalCode) return "Postal code is required"
    }

    if (currentStep === 4) {
      if (!formData.password || formData.password.length < 8) return "Password must be at least 8 characters"
      if (formData.password !== formData.confirmPassword) return "Passwords do not match"
      if (!formData.acceptTerms) return "You must accept the terms and conditions"
    }

    return null
  }

  const handleNextStep = () => {
    const error = validateStep(step)
    if (error) {
      setError(error)
      return
    }

    setStep((prev) => prev + 1)
  }

  const handlePrevStep = () => {
    setStep((prev) => prev - 1)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const error = validateStep(step)
    if (error) {
      setError(error)
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate API call to register the butchery
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Store registration in localStorage for demo purposes
      localStorage.setItem(
        "meatdrop-registration",
        JSON.stringify({
          ...formData,
          registrationDate: new Date().toISOString(),
          status: "pending",
        }),
      )

      // Navigate to success page
      router.push("/signup/success")
    } catch (error) {
      setError("An error occurred during registration. Please try again.")
      console.error("Registration error:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4 py-12">
      <Card className="w-full max-w-2xl">
        <CardHeader className="space-y-1">
          <div className="flex items-center gap-2 mb-2">
            <Beef className="h-8 w-8 text-primary" />
            <CardTitle className="text-2xl font-bold">MeatDrop Butchery Onboarding</CardTitle>
          </div>
          <CardDescription className="text-gray-700">
            Register your butchery business to join the MeatDrop delivery platform
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Step 1: Business Information */}
            {step === 1 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-4">
                  <Building2 className="h-5 w-5 text-primary" />
                  <h2 className="text-xl font-semibold">Business Information</h2>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="businessName" className="text-gray-700">
                    Business Name
                  </Label>
                  <Input
                    id="businessName"
                    placeholder="Your Butchery Name"
                    value={formData.businessName}
                    onChange={(e) => updateFormData("businessName", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="businessType" className="text-gray-700">
                    Business Type
                  </Label>
                  <Select
                    value={formData.businessType}
                    onValueChange={(value) => updateFormData("businessType", value)}
                  >
                    <SelectTrigger id="businessType">
                      <SelectValue placeholder="Select business type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="butchery">Butchery</SelectItem>
                      <SelectItem value="meatProcessor">Meat Processor</SelectItem>
                      <SelectItem value="farmShop">Farm Shop</SelectItem>
                      <SelectItem value="deli">Delicatessen</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="registrationNumber" className="text-gray-700">
                      Business Registration Number
                    </Label>
                    <Input
                      id="registrationNumber"
                      placeholder="Registration Number"
                      value={formData.registrationNumber}
                      onChange={(e) => updateFormData("registrationNumber", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="yearEstablished" className="text-gray-700">
                      Year Established
                    </Label>
                    <Input
                      id="yearEstablished"
                      placeholder="e.g. 2010"
                      value={formData.yearEstablished}
                      onChange={(e) => updateFormData("yearEstablished", e.target.value)}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Contact Information */}
            {step === 2 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-4">
                  <User className="h-5 w-5 text-primary" />
                  <h2 className="text-xl font-semibold">Contact Information</h2>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contactName" className="text-gray-700">
                    Contact Person Name
                  </Label>
                  <Input
                    id="contactName"
                    placeholder="Full Name"
                    value={formData.contactName}
                    onChange={(e) => updateFormData("contactName", e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-gray-700">
                      Email Address
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={(e) => updateFormData("email", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-gray-700">
                      Phone Number
                    </Label>
                    <Input
                      id="phone"
                      placeholder="Phone Number"
                      value={formData.phone}
                      onChange={(e) => updateFormData("phone", e.target.value)}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Address Information */}
            {step === 3 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-4">
                  <MapPin className="h-5 w-5 text-primary" />
                  <h2 className="text-xl font-semibold">Business Address</h2>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address" className="text-gray-700">
                    Street Address
                  </Label>
                  <Textarea
                    id="address"
                    placeholder="Street Address"
                    value={formData.address}
                    onChange={(e) => updateFormData("address", e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="city" className="text-gray-700">
                      City
                    </Label>
                    <Input
                      id="city"
                      placeholder="City"
                      value={formData.city}
                      onChange={(e) => updateFormData("city", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="postalCode" className="text-gray-700">
                      Postal Code
                    </Label>
                    <Input
                      id="postalCode"
                      placeholder="Postal Code"
                      value={formData.postalCode}
                      onChange={(e) => updateFormData("postalCode", e.target.value)}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Account Information */}
            {step === 4 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-4">
                  <Mail className="h-5 w-5 text-primary" />
                  <h2 className="text-xl font-semibold">Account Setup</h2>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-gray-700">
                    Password
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) => updateFormData("password", e.target.value)}
                  />
                  <p className="text-xs text-gray-500">Password must be at least 8 characters long</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-gray-700">
                    Confirm Password
                  </Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="••••••••"
                    value={formData.confirmPassword}
                    onChange={(e) => updateFormData("confirmPassword", e.target.value)}
                  />
                </div>

                <div className="space-y-4 pt-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="acceptTerms"
                      checked={formData.acceptTerms}
                      onCheckedChange={(checked) => updateFormData("acceptTerms", checked === true)}
                    />
                    <Label htmlFor="acceptTerms" className="text-sm text-gray-700">
                      I accept the{" "}
                      <Button variant="link" className="h-auto p-0">
                        terms and conditions
                      </Button>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="acceptMarketing"
                      checked={formData.acceptMarketing}
                      onCheckedChange={(checked) => updateFormData("acceptMarketing", checked === true)}
                    />
                    <Label htmlFor="acceptMarketing" className="text-sm text-gray-700">
                      I agree to receive marketing communications from MeatDrop
                    </Label>
                  </div>
                </div>
              </div>
            )}

            {/* Progress Indicator */}
            <div className="flex justify-between items-center pt-4">
              <div className="flex space-x-1">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className={`h-2 w-10 rounded-full ${i <= step ? "bg-primary" : "bg-gray-200"}`} />
                ))}
              </div>
              <div className="text-sm text-gray-500">Step {step} of 4</div>
            </div>
          </form>
        </CardContent>
        <CardFooter className="flex justify-between">
          {step > 1 ? (
            <Button variant="outline" onClick={handlePrevStep} disabled={isSubmitting}>
              Previous
            </Button>
          ) : (
            <Button variant="outline" onClick={() => router.push("/login")} disabled={isSubmitting}>
              Back to Login
            </Button>
          )}

          {step < 4 ? (
            <Button onClick={handleNextStep} disabled={isSubmitting}>
              Next
            </Button>
          ) : (
            <Button onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? "Submitting..." : "Complete Registration"}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
