"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle, ArrowLeft, CheckCircle2, Clock, Package, ShoppingCart, Truck, User } from "lucide-react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { useMeatdrop, type Order } from "@/components/notifications"
// Remove: import { toast } from "@/components/ui/use-toast"
// Remove: import { ToastAction } from "@/components/ui/toast"

// Product data with prices and inventory IDs
const products = [
  { id: 1, name: "Ribeye Steak", price: 299.99, unit: "kg" },
  { id: 7, name: "T-Bone Steak", price: 349.99, unit: "kg" },
  { id: 3, name: "Chicken Breast", price: 279.99, unit: "kg" },
  { id: 5, name: "Ground Beef", price: 399.99, unit: "kg" },
  { id: 6, name: "Pork Sausages", price: 199.99, unit: "kg" },
  { id: 2, name: "Pork Belly", price: 249.99, unit: "kg" },
  { id: 4, name: "Lamb Chops", price: 399.99, unit: "kg" },
  { id: 8, name: "Beef Brisket", price: 349.99, unit: "kg" },
]

// Customer data for simulation
const customers = [
  { id: "john", name: "John Smith", email: "john@example.com", phone: "555-123-4567", address: "123 Main St, Anytown" },
  {
    id: "sarah",
    name: "Sarah Johnson",
    email: "sarah@example.com",
    phone: "555-234-5678",
    address: "456 Oak Ave, Somewhere",
  },
  {
    id: "michael",
    name: "Michael Brown",
    email: "michael@example.com",
    phone: "555-345-6789",
    address: "789 Pine Rd, Elsewhere",
  },
  {
    id: "emily",
    name: "Emily Davis",
    email: "emily@example.com",
    phone: "555-456-7890",
    address: "101 Cedar Ln, Nowhere",
  },
]

// Driver data for simulation with proximity data
const drivers = [
  {
    id: "driver1",
    name: "Alex Johnson",
    phone: "555-111-2222",
    status: "Available",
    rating: 4.8,
    avatar: "/placeholder.svg?height=40&width=40",
    proximity: 2.3, // km from customer
    estimatedArrival: "5 mins",
  },
  {
    id: "driver2",
    name: "Maria Garcia",
    phone: "555-222-3333",
    status: "Available",
    rating: 4.9,
    avatar: "/placeholder.svg?height=40&width=40",
    proximity: 1.1, // km from customer
    estimatedArrival: "3 mins",
  },
  {
    id: "driver3",
    name: "David Lee",
    phone: "555-333-4444",
    status: "Busy",
    rating: 4.7,
    avatar: "/placeholder.svg?height=40&width=40",
    proximity: 5.7, // km from customer
    estimatedArrival: "12 mins",
  },
  {
    id: "driver4",
    name: "Lisa Chen",
    phone: "555-444-5555",
    status: "Available",
    rating: 4.6,
    avatar: "/placeholder.svg?height=40&width=40",
    proximity: 3.2, // km from customer
    estimatedArrival: "7 mins",
  },
]

// Order status steps
const orderStatuses = [
  { id: "received", label: "Order Received", icon: ShoppingCart },
  { id: "processing", label: "Processing", icon: Package },
  { id: "driver_assigned", label: "Driver Assigned", icon: User },
  { id: "out_for_delivery", label: "Out for Delivery", icon: Truck },
  { id: "delivered", label: "Delivered", icon: CheckCircle2 },
]

export default function SimulateOrderPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const orderId = searchParams.get("id") || `ORD-${Math.floor(1000 + Math.random() * 9000)}`

  const { pendingOrders, processedOrders, setProcessedOrders, setInventoryUpdates } = useMeatdrop()

  const [orderStatus, setOrderStatus] = useState("received")
  const [selectedDriver, setSelectedDriver] = useState("")
  const [processingStep, setProcessingStep] = useState(0)
  const [isProcessing, setIsProcessing] = useState(false)
  const [notes, setNotes] = useState("")
  const [driverResponses, setDriverResponses] = useState<Record<string, string>>({})
  const [autoAssignInProgress, setAutoAssignInProgress] = useState(false)
  const [assignmentAttempts, setAssignmentAttempts] = useState(0)
  const [inventoryUpdated, setInventoryUpdated] = useState(false)
  const [orderDetails, setOrderDetails] = useState<Order | null>(null)

  // Find the order in pending orders
  useEffect(() => {
    const foundOrder = pendingOrders.find((order) => order.id === orderId)
    if (foundOrder) {
      setOrderDetails(foundOrder)
    } else if (orderId) {
      // If not found in pending orders but we have an ID, create a simulated order
      const randomProduct = products[Math.floor(Math.random() * products.length)]
      const randomCustomer = customers[Math.floor(Math.random() * customers.length)]
      const quantity = (Math.floor(Math.random() * 3) + 1) / 2 // 0.5, 1, 1.5, or 2 kg

      const simulatedOrder: Order = {
        id: orderId,
        customer: randomCustomer.name,
        items: [
          {
            name: randomProduct.name,
            quantity: quantity,
            unit: "kg",
            productId: randomProduct.id,
          },
        ],
        total: `R${(randomProduct.price * quantity).toFixed(2)}`,
        time: "Just now",
        avatar: "/placeholder.svg?height=32&width=32",
      }

      setOrderDetails(simulatedOrder)
    }
  }, [orderId, pendingOrders])

  // Get available drivers sorted by proximity
  const availableDrivers = drivers
    .filter((driver) => driver.status === "Available")
    .sort((a, b) => a.proximity - b.proximity)

  // Auto-assign the closest driver
  const autoAssignDriver = () => {
    setAutoAssignInProgress(true)
    setIsProcessing(true)

    // If we've tried all available drivers, show an alert
    if (assignmentAttempts >= availableDrivers.length) {
      alert("No available drivers at this time. Please try manual assignment.")
      setAutoAssignInProgress(false)
      setIsProcessing(false)
      return
    }

    // Get the next closest driver who hasn't declined
    const nextDriver = availableDrivers[assignmentAttempts]

    if (!nextDriver) {
      alert("No available drivers at this time. Please try manual assignment.")
      setAutoAssignInProgress(false)
      setIsProcessing(false)
      return
    }

    // Simulate driver response time (1-3 seconds)
    const responseTime = 1000 + Math.random() * 2000

    setTimeout(() => {
      // 80% chance of accepting for simulation purposes
      const willAccept = Math.random() < 0.8

      if (willAccept) {
        setSelectedDriver(nextDriver.id)
        setDriverResponses((prev) => ({ ...prev, [nextDriver.id]: "Accepted" }))
        setOrderStatus("driver_assigned")
        setProcessingStep(2)
        setAutoAssignInProgress(false)
        setIsProcessing(false)
      } else {
        // Driver declined, try next closest
        setDriverResponses((prev) => ({ ...prev, [nextDriver.id]: "Declined" }))
        setAssignmentAttempts((prev) => prev + 1)

        // Try the next driver after a short delay
        setTimeout(() => {
          autoAssignDriver()
        }, 500)
      }
    }, responseTime)
  }

  // Handle order processing and inventory updates
  const handleProcessOrder = () => {
    setIsProcessing(true)

    // Mark this order as processed to remove from notifications
    setProcessedOrders((prev) => [...prev, orderId])

    // Update inventory for each item in the order
    if (orderDetails && orderDetails.items) {
      // Create inventory updates for each product
      const updates = orderDetails.items.map((item) => ({
        productId: item.productId,
        name: item.name,
        change: -item.quantity, // Negative because we're reducing inventory
      }))

      // Update inventory
      setInventoryUpdates((prev) => [...prev, ...updates])
      setInventoryUpdated(true)

      // Replace the following code in handleProcessOrder:
      // \`\`\`
      // Show toast notification for inventory update
      // toast({
      //   title: "Inventory Updated",
      //   description: `${orderDetails.items.length} product(s) have been deducted from inventory.`,
      //   action: (
      //     <ToastAction altText="View Inventory" onClick={() => router.push("/inventory")}>
      //       View Inventory
      //     </ToastAction>
      //   ),
      // })
      // \`\`\`

      // With:
      // \`\`\`
      // We're still tracking inventory changes, but without the popup notification
      // console.log(`Inventory updated: ${orderDetails.items.length} product(s) deducted from inventory.`);
      // \`\`\`
      // We're still tracking inventory changes, but without the popup notification
      console.log(`Inventory updated: ${orderDetails.items.length} product(s) deducted from inventory.`)
    }

    // Simulate processing delay
    setTimeout(() => {
      setIsProcessing(false)
      setOrderStatus("processing")
      setProcessingStep(1)
    }, 1500)
  }

  // Handle marking as out for delivery
  const handleOutForDelivery = () => {
    setIsProcessing(true)

    // Simulate delay
    setTimeout(() => {
      setIsProcessing(false)
      setOrderStatus("out_for_delivery")
      setProcessingStep(3)
    }, 1500)
  }

  // Handle marking as delivered
  const handleDelivered = () => {
    setIsProcessing(true)

    // Simulate delay
    setTimeout(() => {
      setIsProcessing(false)
      setOrderStatus("delivered")
      setProcessingStep(4)
    }, 1500)
  }

  // Get current status index
  const currentStatusIndex = orderStatuses.findIndex((status) => status.id === orderStatus)

  // If order details aren't loaded yet, show loading
  if (!orderDetails) {
    return (
      <DashboardShell>
        <DashboardHeader heading="Order Processing" text="Loading order details...">
          <Button variant="outline" asChild>
            <Link href="/orders">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Orders
            </Link>
          </Button>
        </DashboardHeader>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </DashboardShell>
    )
  }

  // Calculate order totals
  const items = orderDetails.items
  const subtotal = items.reduce((total, item) => {
    const product = products.find((p) => p.id === item.productId)
    return total + (product ? product.price * item.quantity : 0)
  }, 0)
  const deliveryFee = 35.0
  const tax = subtotal * 0.15 // 15% VAT
  const total = subtotal + tax + deliveryFee

  return (
    <DashboardShell>
      <DashboardHeader heading="Order Processing" text="Process incoming customer order">
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link href="/orders">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Orders
            </Link>
          </Button>
          {processingStep >= 2 && (
            <Button variant="outline" asChild>
              <Link href="/deliveries">
                View Deliveries
                <Truck className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          )}
        </div>
      </DashboardHeader>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Order #{orderId}</CardTitle>
              <CardDescription className="text-black">Received {orderDetails.time}</CardDescription>
            </div>
            <Badge variant={orderStatus === "received" ? "default" : "outline"}>
              {orderStatus === "received" ? "New Order" : "In Progress"}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-medium text-black">Customer Details</h3>
                <div className="mt-2 rounded-md bg-muted p-4">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={orderDetails.avatar || "/placeholder.svg"} alt={orderDetails.customer} />
                      <AvatarFallback>{orderDetails.customer.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium text-black">{orderDetails.customer}</div>
                      <div className="text-sm text-black">
                        {customers.find((c) => c.name === orderDetails.customer)?.email || "customer@example.com"}
                      </div>
                      <div className="text-sm text-black">
                        {customers.find((c) => c.name === orderDetails.customer)?.phone || "555-123-4567"}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3 text-sm text-black">
                    <div className="font-medium">Delivery Address:</div>
                    <div>
                      {customers.find((c) => c.name === orderDetails.customer)?.address || "123 Main St, Anytown"}
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-black">Order Items</h3>
                <div className="mt-2 rounded-md bg-muted p-4">
                  {items.map((item, index) => (
                    <div key={index} className="flex items-center justify-between mb-2">
                      <div className="text-black">
                        <span className="font-medium">{item.name}</span>
                        <span className="ml-2 text-sm">
                          ({item.quantity} {item.unit})
                        </span>
                      </div>
                      <div className="font-medium text-black">
                        R{(products.find((p) => p.id === item.productId)?.price || 0 * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  ))}
                  <Separator className="my-3" />
                  <div className="space-y-1 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-black">Subtotal</span>
                      <span className="text-black">R{subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-black">Delivery Fee</span>
                      <span className="text-black">R{deliveryFee.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-black">VAT (15%)</span>
                      <span className="text-black">R{tax.toFixed(2)}</span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex items-center justify-between font-medium">
                      <span className="text-black">Total</span>
                      <span className="text-black">R{total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-black">Order Notes</h3>
                <Textarea
                  placeholder="Add notes about this order..."
                  className="mt-2"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-medium text-black">Order Status</h3>
                <div className="mt-2 space-y-3">
                  {orderStatuses.map((status, index) => {
                    const StatusIcon = status.icon
                    const isActive = index <= currentStatusIndex
                    const isCurrent = index === currentStatusIndex

                    return (
                      <div key={status.id} className="flex items-center gap-3">
                        <div
                          className={`rounded-full p-2 ${isActive ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}
                        >
                          <StatusIcon className="h-4 w-4" />
                        </div>
                        <div
                          className={`text-sm ${isCurrent ? "font-medium text-black" : isActive ? "text-black" : "text-muted-foreground"}`}
                        >
                          {status.label}
                          {isActive && index < currentStatusIndex && (
                            <span className="ml-2 text-xs text-muted-foreground">
                              {new Date(Date.now() - (4 - index) * 2 * 60000).toLocaleTimeString()}
                            </span>
                          )}
                        </div>
                        {isCurrent && (
                          <Badge variant="outline" className="ml-auto">
                            Current
                          </Badge>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>

              {inventoryUpdated && (
                <Alert className="bg-green-50 border-green-200 mb-4">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <AlertTitle className="text-green-800">Inventory Updated</AlertTitle>
                  <AlertDescription className="text-green-700">
                    {items.map((item) => `${item.quantity}${item.unit} of ${item.name}`).join(", ")} has been deducted
                    from inventory.
                  </AlertDescription>
                </Alert>
              )}

              {processingStep >= 1 && (
                <div>
                  <h3 className="text-lg font-medium text-black">Driver Assignment</h3>

                  {autoAssignInProgress ? (
                    <div className="mt-4 space-y-4">
                      <div className="flex items-center justify-center">
                        <Clock className="h-8 w-8 text-primary animate-pulse" />
                      </div>
                      <Progress value={assignmentAttempts * 25} className="h-2" />
                      <p className="text-center text-sm text-black">Auto-assigning to closest available driver...</p>
                      {Object.entries(driverResponses).map(([driverId, response]) => {
                        const driver = drivers.find((d) => d.id === driverId)
                        return (
                          <div key={driverId} className="flex items-center justify-between rounded-md bg-muted p-2">
                            <div className="flex items-center gap-2">
                              <Avatar className="h-6 w-6">
                                <AvatarImage src={driver?.avatar || "/placeholder.svg"} alt={driver?.name} />
                                <AvatarFallback>{driver?.name.charAt(0) || "D"}</AvatarFallback>
                              </Avatar>
                              <span className="text-sm text-black">{driver?.name}</span>
                            </div>
                            <Badge variant={response === "Accepted" ? "default" : "destructive"}>{response}</Badge>
                          </div>
                        )
                      })}
                    </div>
                  ) : selectedDriver ? (
                    <div className="mt-3 rounded-md bg-muted p-3">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage
                            src={drivers.find((d) => d.id === selectedDriver)?.avatar || "/placeholder.svg"}
                            alt="Driver"
                          />
                          <AvatarFallback>
                            {drivers.find((d) => d.id === selectedDriver)?.name.charAt(0) || "D"}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium text-black">
                            {drivers.find((d) => d.id === selectedDriver)?.name}
                          </div>
                          <div className="text-sm text-black">
                            Rating: {drivers.find((d) => d.id === selectedDriver)?.rating} ★
                          </div>
                          <div className="text-sm text-black">
                            {drivers.find((d) => d.id === selectedDriver)?.phone}
                          </div>
                          <div className="text-sm text-black">
                            Distance: {drivers.find((d) => d.id === selectedDriver)?.proximity} km
                          </div>
                          <div className="text-sm text-black">
                            ETA: {drivers.find((d) => d.id === selectedDriver)?.estimatedArrival}
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-4 space-y-4">
                      <Alert className="bg-blue-50 border-blue-200">
                        <AlertCircle className="h-4 w-4 text-blue-600" />
                        <AlertTitle className="text-blue-800">Time-Sensitive Delivery</AlertTitle>
                        <AlertDescription className="text-blue-700">
                          Meat products require prompt delivery. Use auto-assign to find the closest driver.
                        </AlertDescription>
                      </Alert>

                      <div className="space-y-2">
                        <h4 className="text-sm font-medium text-black">Available Drivers by Proximity</h4>
                        {availableDrivers.map((driver) => (
                          <div key={driver.id} className="flex items-center justify-between rounded-md bg-muted p-2">
                            <div className="flex items-center gap-2">
                              <Avatar className="h-6 w-6">
                                <AvatarImage src={driver.avatar || "/placeholder.svg"} alt={driver.name} />
                                <AvatarFallback>{driver.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="text-sm font-medium text-black">{driver.name}</div>
                                <div className="text-xs text-muted-foreground">
                                  {driver.proximity} km away • {driver.estimatedArrival}
                                </div>
                              </div>
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {driver.rating} ★
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {processingStep >= 2 && (
                <Alert className="bg-blue-50 border-blue-200">
                  <Truck className="h-4 w-4 text-blue-600" />
                  <AlertTitle className="text-blue-800">Driver Assigned</AlertTitle>
                  <AlertDescription className="text-blue-700">
                    {drivers.find((d) => d.id === selectedDriver)?.name} has been assigned to this order.
                    <br />
                    Estimated arrival: {drivers.find((d) => d.id === selectedDriver)?.estimatedArrival}
                  </AlertDescription>
                </Alert>
              )}

              {processingStep >= 3 && (
                <Alert className="bg-blue-50 border-blue-200">
                  <Truck className="h-4 w-4 text-blue-600" />
                  <AlertTitle className="text-blue-800">Out for Delivery</AlertTitle>
                  <AlertDescription className="text-blue-700">
                    Order is now out for delivery with {drivers.find((d) => d.id === selectedDriver)?.name}.
                  </AlertDescription>
                </Alert>
              )}

              {processingStep >= 4 && (
                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <AlertTitle className="text-green-800">Delivered Successfully</AlertTitle>
                  <AlertDescription className="text-green-700">
                    Order was delivered at {new Date().toLocaleTimeString()}.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end">
          <div className="space-x-2">
            {orderStatus === "received" && (
              <Button onClick={handleProcessOrder} disabled={isProcessing}>
                {isProcessing ? "Processing..." : "Process Order"}
              </Button>
            )}

            {orderStatus === "processing" && !selectedDriver && !autoAssignInProgress && (
              <Button onClick={autoAssignDriver} disabled={isProcessing}>
                Auto-Assign Closest Driver
              </Button>
            )}

            {orderStatus === "driver_assigned" && (
              <Button onClick={handleOutForDelivery} disabled={isProcessing}>
                {isProcessing ? "Updating..." : "Mark as Out for Delivery"}
              </Button>
            )}

            {orderStatus === "out_for_delivery" && (
              <Button onClick={handleDelivered} disabled={isProcessing}>
                {isProcessing ? "Completing..." : "Mark as Delivered"}
              </Button>
            )}

            {orderStatus === "delivered" && (
              <Button variant="outline" onClick={() => router.push("/deliveries?processed=" + orderId)}>
                View in Deliveries
              </Button>
            )}
          </div>
        </CardFooter>
      </Card>
    </DashboardShell>
  )
}
