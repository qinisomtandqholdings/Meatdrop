"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useRouter } from "next/navigation"
import { ExternalLink, Filter, MoreHorizontal, Plus, Search } from "lucide-react"

export default function OrdersPage() {
  const router = useRouter()
  const [orders] = useState([
    {
      id: "ORD-1234",
      customer: "John Smith",
      date: new Date(2023, 5, 20).toLocaleDateString(),
      items: "Ribeye Steak (2kg), Ground Beef (1kg)",
      total: "R89.99",
      status: "Processing",
    },
    {
      id: "ORD-1233",
      customer: "Sarah Johnson",
      date: new Date(2023, 5, 19).toLocaleDateString(),
      items: "Pork Chops (1kg), Chicken Breast (2kg)",
      total: "R67.50",
      status: "Out for Delivery",
    },
    {
      id: "ORD-1232",
      customer: "Michael Brown",
      date: new Date(2023, 5, 18).toLocaleDateString(),
      items: "Lamb Rack (1.5kg), Sausages (1kg)",
      total: "R112.75",
      status: "Delivered",
    },
    {
      id: "ORD-1231",
      customer: "Emily Davis",
      date: new Date(2023, 5, 17).toLocaleDateString(),
      items: "T-Bone Steak (1kg), Beef Brisket (2kg)",
      total: "R95.25",
      status: "Cancelled",
    },
  ])

  const handleProcessOrder = (orderId: string) => {
    router.push(`/orders/simulate?id=${orderId}`)
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Orders" text="Manage customer orders">
        <div className="flex gap-2">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            <span>New Order</span>
            <ExternalLink className="ml-2 h-3 w-3" />
          </Button>
        </div>
      </DashboardHeader>
      <div className="space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search orders..." className="pl-8 w-[300px]" />
            </div>
            <Button variant="outline" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-black">Order ID</TableHead>
                <TableHead className="text-black">Customer</TableHead>
                <TableHead className="text-black">Date</TableHead>
                <TableHead className="text-black">Items</TableHead>
                <TableHead className="text-black">Total</TableHead>
                <TableHead className="text-black">Status</TableHead>
                <TableHead className="text-right text-black">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((order, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium text-black">{order.id}</TableCell>
                  <TableCell className="text-black">{order.customer}</TableCell>
                  <TableCell className="text-black">{order.date}</TableCell>
                  <TableCell className="text-black">{order.items}</TableCell>
                  <TableCell className="text-black">{order.total}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        order.status === "Processing"
                          ? "default"
                          : order.status === "Out for Delivery"
                            ? "secondary"
                            : order.status === "Delivered"
                              ? "outline"
                              : "destructive"
                      }
                    >
                      {order.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Open menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleProcessOrder(order.id)}>Process order</DropdownMenuItem>
                        <DropdownMenuItem>View details</DropdownMenuItem>
                        <DropdownMenuItem>Contact customer</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </DashboardShell>
  )
}
