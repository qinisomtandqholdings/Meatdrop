"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import DashboardShell from "@/components/dashboard-shell"  // Import your dashboard layout

export default function DashboardPage() {
  const router = useRouter()

  // Check if the user is logged in, otherwise redirect to login page
  useEffect(() => {
    const auth = JSON.parse(localStorage.getItem("meatdrop-auth") || "{}")
    if (!auth?.isLoggedIn) {
      router.push("/login")  // Redirect to login page if not logged in
    }
  }, [])

  return <DashboardShell />  // Replace with your actual dashboard content
}

