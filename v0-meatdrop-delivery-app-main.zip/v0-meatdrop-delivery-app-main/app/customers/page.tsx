import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ExternalLink, Filter, MoreHorizontal, Search, UserPlus } from "lucide-react"

export default function CustomersPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Customers" text="View and manage your customer base">
        <Button>
          <UserPlus className="mr-2 h-4 w-4" />
          <span>Import Customers</span>
          <ExternalLink className="ml-2 h-3 w-3" />
        </Button>
      </DashboardHeader>
      <div className="space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search customers..." className="pl-8 w-[300px]" />
            </div>
            <Button variant="outline" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-black">Name</TableHead>
                <TableHead className="text-black">Email</TableHead>
                <TableHead className="text-black">Phone</TableHead>
                <TableHead className="text-black">Orders</TableHead>
                <TableHead className="text-black">Total Spent</TableHead>
                <TableHead className="text-black">Status</TableHead>
                <TableHead className="text-right text-black">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[
                {
                  name: "John Smith",
                  email: "john@example.com",
                  phone: "555-123-4567",
                  orders: 12,
                  spent: 458.75,
                  status: "Active",
                },
                {
                  name: "Sarah Johnson",
                  email: "sarah@example.com",
                  phone: "555-234-5678",
                  orders: 8,
                  spent: 325.5,
                  status: "Active",
                },
                {
                  name: "Michael Brown",
                  email: "michael@example.com",
                  phone: "555-345-6789",
                  orders: 5,
                  spent: 189.25,
                  status: "Active",
                },
                {
                  name: "Emily Davis",
                  email: "emily@example.com",
                  phone: "555-456-7890",
                  orders: 3,
                  spent: 142.75,
                  status: "Inactive",
                },
                {
                  name: "Robert Wilson",
                  email: "robert@example.com",
                  phone: "555-567-8901",
                  orders: 7,
                  spent: 278.5,
                  status: "Active",
                },
                {
                  name: "Jennifer Taylor",
                  email: "jennifer@example.com",
                  phone: "555-678-9012",
                  orders: 0,
                  spent: 0,
                  status: "New",
                },
                {
                  name: "David Martinez",
                  email: "david@example.com",
                  phone: "555-789-0123",
                  orders: 4,
                  spent: 167.25,
                  status: "Active",
                },
                {
                  name: "Lisa Anderson",
                  email: "lisa@example.com",
                  phone: "555-890-1234",
                  orders: 2,
                  spent: 89.5,
                  status: "Inactive",
                },
              ].map((customer, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium text-black">{customer.name}</TableCell>
                  <TableCell className="text-black">{customer.email}</TableCell>
                  <TableCell className="text-black">{customer.phone}</TableCell>
                  <TableCell className="text-black">{customer.orders}</TableCell>
                  <TableCell className="text-black">R{customer.spent.toFixed(2)}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        customer.status === "Active" ? "default" : customer.status === "New" ? "secondary" : "outline"
                      }
                    >
                      {customer.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Open menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>View details</DropdownMenuItem>
                        <DropdownMenuItem>Order history</DropdownMenuItem>
                        <DropdownMenuItem>Edit customer</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      <div className="mt-6">
        <Card>
          <CardHeader>
            <CardTitle>Customer Insights</CardTitle>
            <CardDescription className="text-black">Overview of your customer base</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <div className="text-xl font-bold">573</div>
                <div className="text-sm font-medium text-black">Total Customers</div>
                <div className="text-xs text-black">+18% from last month</div>
              </div>
              <div className="space-y-2">
                <div className="text-xl font-bold">R42.50</div>
                <div className="text-sm font-medium text-black">Average Order Value</div>
                <div className="text-xs text-black">+5% from last month</div>
              </div>
              <div className="space-y-2">
                <div className="text-xl font-bold">68%</div>
                <div className="text-sm font-medium text-black">Repeat Customers</div>
                <div className="text-xs text-black">+12% from last month</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}
