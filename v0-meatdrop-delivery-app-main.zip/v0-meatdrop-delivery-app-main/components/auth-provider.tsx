"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"

type User = {
  email: string
  role: string
}

type AuthContextType = {
  user: User | null
  isLoggedIn: boolean
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoggedIn: false,
  login: async () => false,
  logout: () => {},
})

export const useAuth = () => useContext(AuthContext)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  // Update the AuthProvider to automatically authenticate the user

  // Change the initial state to be logged in by default
  const [user, setUser] = useState<User | null>({ email: "admin@meatdrop.com", role: "admin" })
  const [isLoggedIn, setIsLoggedIn] = useState(true)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const pathname = usePathname()

  // Update the useEffect to properly handle authentication state

  // Replace the useEffect that checks authentication with this simplified version
  useEffect(() => {
    // Automatically set authentication in localStorage
    localStorage.setItem(
      "meatdrop-auth",
      JSON.stringify({
        isLoggedIn: true,
        user: { email: "admin@meatdrop.com", role: "admin" },
        timestamp: new Date().toISOString(),
      }),
    )
    setIsLoading(false)
  }, [])

  // Remove or comment out the redirect useEffect
  // useEffect(() => {
  //   // List of public paths that don't require authentication
  //   const publicPaths = ["/login", "/forgot-password", "/reset-password", "/signup", "/signup/success"]

  //   if (!isLoading && !isLoggedIn && !publicPaths.some((path) => pathname?.startsWith(path))) {
  //     router.push("/login")
  //   }
  // }, [isLoading, isLoggedIn, pathname, router])

  // Update the login function to be more permissive and always succeed
  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // Always allow login for development purposes
      const userData = { email: email || "admin@meatdrop.com", role: "admin" }
      setUser(userData)
      setIsLoggedIn(true)

      // Store in localStorage
      localStorage.setItem(
        "meatdrop-auth",
        JSON.stringify({
          isLoggedIn: true,
          user: userData,
          timestamp: new Date().toISOString(),
        }),
      )

      return true
    } catch (error) {
      console.error("Login error:", error)
      return false
    }
  }

  const logout = () => {
    setUser(null)
    setIsLoggedIn(false)
    localStorage.removeItem("meatdrop-auth")
    router.push("/login")
  }

  return (
    <AuthContext.Provider value={{ user, isLoggedIn, login, logout }}>
      {!isLoading &&
      (isLoggedIn ||
        pathname === "/login" ||
        pathname === "/forgot-password" ||
        pathname === "/reset-password" ||
        pathname?.startsWith("/signup"))
        ? children
        : null}
    </AuthContext.Provider>
  )
}
