"use client"

import { useEffect, useState } from "react"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"

export function InventoryOverview() {
  const [inventory, setInventory] = useState([
    {
      id: 1,
      name: "Ribeye Steak",
      category: "Beef",
      stock: 15,
      maxStock: 100,
      status: "Low",
    },
    {
      id: 2,
      name: "Pork Belly",
      category: "Pork",
      stock: 8,
      maxStock: 50,
      status: "Low",
    },
    {
      id: 3,
      name: "Chicken Breast",
      category: "Poultry",
      stock: 45,
      maxStock: 80,
      status: "Good",
    },
    {
      id: 4,
      name: "Lamb Chops",
      category: "Lamb",
      stock: 12,
      maxStock: 40,
      status: "Low",
    },
    {
      id: 5,
      name: "Ground Beef",
      category: "Beef",
      stock: 60,
      maxStock: 100,
      status: "Good",
    },
  ])

  // Load inventory from localStorage on initial load
  useEffect(() => {
    const savedInventory = localStorage.getItem("meatdrop-inventory")
    if (savedInventory) {
      try {
        const fullInventory = JSON.parse(savedInventory)
        // Take the first 5 items for the overview
        setInventory(fullInventory.slice(0, 5))
      } catch (e) {
        console.error("Failed to parse saved inventory", e)
      }
    }
  }, [])

  return (
    <div className="space-y-4">
      {inventory.map((item) => (
        <div key={item.id} className="flex items-center gap-4">
          <div className="flex-1 space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-medium">{item.name}</span>
              <Badge
                variant={item.status === "Low" ? "destructive" : "outline"}
                className={item.status === "Good" ? "bg-green-700 hover:bg-green-800 text-white" : ""}
              >
                {item.status}
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground">{item.category}</div>
            <Progress value={(item.stock / item.maxStock) * 100} className="h-2" />
          </div>
          <div className="text-sm font-medium">{item.stock} kg</div>
        </div>
      ))}
    </div>
  )
}
