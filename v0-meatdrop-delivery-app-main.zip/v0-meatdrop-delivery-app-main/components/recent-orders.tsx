import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export function RecentOrders() {
  const orders = [
    {
      id: "ORD-1234",
      customer: {
        name: "John Smith",
        email: "john@example.com",
        avatar: "/placeholder.svg?height=32&width=32",
      },
      items: ["Ribeye Steak (2kg)", "Ground Beef (1kg)"],
      total: "R89.99",
      status: "Processing",
      time: "10 minutes ago",
    },
    {
      id: "ORD-1233",
      customer: {
        name: "Sarah Johnson",
        email: "sarah@example.com",
        avatar: "/placeholder.svg?height=32&width=32",
      },
      items: ["Pork Chops (1kg)", "Chicken Breast (2kg)"],
      total: "R67.50",
      status: "Preparing",
      time: "25 minutes ago",
    },
    {
      id: "ORD-1232",
      customer: {
        name: "Michael Brown",
        email: "michael@example.com",
        avatar: "/placeholder.svg?height=32&width=32",
      },
      items: ["Lamb Rack (1.5kg)", "Sausages (1kg)"],
      total: "R112.75",
      status: "Out for Delivery",
      time: "1 hour ago",
    },
    {
      id: "ORD-1231",
      customer: {
        name: "Emily Davis",
        email: "emily@example.com",
        avatar: "/placeholder.svg?height=32&width=32",
      },
      items: ["T-Bone Steak (1kg)", "Beef Brisket (2kg)"],
      total: "R95.25",
      status: "Delivered",
      time: "2 hours ago",
    },
  ]

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <Card key={order.id} className="p-4">
          <div className="grid gap-4 md:grid-cols-[1fr_200px]">
            <div className="flex items-start gap-4">
              <Avatar className="hidden sm:flex">
                <AvatarImage src={order.customer.avatar || "/placeholder.svg"} alt={order.customer.name} />
                <AvatarFallback>{order.customer.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="grid gap-1">
                <div className="font-semibold">{order.customer.name}</div>
                <div className="text-sm text-muted-foreground">{order.customer.email}</div>
                <div className="text-sm font-medium">{order.items.join(", ")}</div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>{order.id}</span>
                  <span>•</span>
                  <span>{order.time}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2">
              <Badge
                variant={
                  order.status === "Delivered"
                    ? "outline"
                    : order.status === "Out for Delivery"
                      ? "secondary"
                      : order.status === "Processing"
                        ? "default"
                        : "destructive"
                }
              >
                {order.status}
              </Badge>
              <div className="font-medium">{order.total}</div>
              <Button variant="ghost" size="icon">
                <span className="sr-only">Actions</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4"
                >
                  <circle cx="12" cy="12" r="1" />
                  <circle cx="12" cy="5" r="1" />
                  <circle cx="12" cy="19" r="1" />
                </svg>
              </Button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
