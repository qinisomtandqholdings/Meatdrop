"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { BarChart, LineChart } from "@/components/charts"

// Sample delivery data
const deliveryData = [
  {
    id: "DEL-1234",
    orderId: "ORD-1234",
    driver: "Alex Johnson",
    customer: "John Smith",
    distance: 5.2,
    duration: 28,
    status: "Delivered",
    rating: 5,
  },
  {
    id: "DEL-1233",
    orderId: "ORD-1233",
    driver: "Maria Garcia",
    customer: "Sarah Johnson",
    distance: 3.8,
    duration: 22,
    status: "Delivered",
    rating: 4,
  },
  {
    id: "DEL-1232",
    orderId: "ORD-1232",
    driver: "David Lee",
    customer: "Michael Brown",
    distance: 7.5,
    duration: 35,
    status: "Delivered",
    rating: 5,
  },
  {
    id: "DEL-1231",
    orderId: "ORD-1231",
    driver: "Lisa Chen",
    customer: "Emily Davis",
    distance: 4.1,
    duration: 25,
    status: "Delivered",
    rating: 4,
  },
  {
    id: "DEL-1230",
    orderId: "ORD-1230",
    driver: "James Wilson",
    customer: "Robert Wilson",
    distance: 6.3,
    duration: 32,
    status: "Delivered",
    rating: 3,
  },
  {
    id: "DEL-1229",
    orderId: "ORD-1229",
    driver: "Alex Johnson",
    customer: "Jennifer Taylor",
    distance: 2.9,
    duration: 18,
    status: "Delivered",
    rating: 5,
  },
  {
    id: "DEL-1228",
    orderId: "ORD-1228",
    driver: "Maria Garcia",
    customer: "David Martinez",
    distance: 5.7,
    duration: 30,
    status: "Delivered",
    rating: 4,
  },
]

export function DeliveryReport() {
  // Calculate delivery statistics
  const totalDeliveries = deliveryData.length
  const averageDistance = deliveryData.reduce((sum, delivery) => sum + delivery.distance, 0) / totalDeliveries
  const averageDuration = deliveryData.reduce((sum, delivery) => sum + delivery.duration, 0) / totalDeliveries
  const averageRating = deliveryData.reduce((sum, delivery) => sum + delivery.rating, 0) / totalDeliveries

  // Get unique drivers
  const drivers = [...new Set(deliveryData.map((delivery) => delivery.driver))]

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Deliveries</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalDeliveries}</div>
            <p className="text-xs text-gray-600">For the selected period</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Average Distance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageDistance.toFixed(1)} km</div>
            <p className="text-xs text-gray-600">Per delivery</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Average Duration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageDuration.toFixed(0)} min</div>
            <p className="text-xs text-gray-600">From order to delivery</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Customer Satisfaction</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageRating.toFixed(1)}/5</div>
            <p className="text-xs text-gray-600">Average rating</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <BarChart title="Deliveries by Driver" description="Number of deliveries completed by each driver" />
        <LineChart title="Delivery Times" description="Average delivery duration by day" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Driver Performance</CardTitle>
          <CardDescription className="text-gray-700">Performance metrics for each driver</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-black">Driver</TableHead>
                <TableHead className="text-black">Deliveries</TableHead>
                <TableHead className="text-black">Avg. Distance</TableHead>
                <TableHead className="text-black">Avg. Duration</TableHead>
                <TableHead className="text-black">Avg. Rating</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {drivers.map((driver) => {
                const driverDeliveries = deliveryData.filter((d) => d.driver === driver)
                const count = driverDeliveries.length
                const avgDistance = driverDeliveries.reduce((sum, d) => sum + d.distance, 0) / count
                const avgDuration = driverDeliveries.reduce((sum, d) => sum + d.duration, 0) / count
                const avgRating = driverDeliveries.reduce((sum, d) => sum + d.rating, 0) / count

                return (
                  <TableRow key={driver}>
                    <TableCell className="font-medium text-black">{driver}</TableCell>
                    <TableCell className="text-black">{count}</TableCell>
                    <TableCell className="text-black">{avgDistance.toFixed(1)} km</TableCell>
                    <TableCell className="text-black">{avgDuration.toFixed(0)} min</TableCell>
                    <TableCell className="text-black">{avgRating.toFixed(1)}/5</TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Delivery Details</CardTitle>
          <CardDescription className="text-gray-700">Individual delivery records</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-black">Delivery ID</TableHead>
                <TableHead className="text-black">Order ID</TableHead>
                <TableHead className="text-black">Driver</TableHead>
                <TableHead className="text-black">Customer</TableHead>
                <TableHead className="text-black">Distance</TableHead>
                <TableHead className="text-black">Duration</TableHead>
                <TableHead className="text-black">Rating</TableHead>
                <TableHead className="text-black">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {deliveryData.map((delivery) => (
                <TableRow key={delivery.id}>
                  <TableCell className="font-medium text-black">{delivery.id}</TableCell>
                  <TableCell className="text-black">{delivery.orderId}</TableCell>
                  <TableCell className="text-black">{delivery.driver}</TableCell>
                  <TableCell className="text-black">{delivery.customer}</TableCell>
                  <TableCell className="text-black">{delivery.distance} km</TableCell>
                  <TableCell className="text-black">{delivery.duration} min</TableCell>
                  <TableCell className="text-black">{delivery.rating}/5</TableCell>
                  <TableCell>
                    <Badge variant="outline">{delivery.status}</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
