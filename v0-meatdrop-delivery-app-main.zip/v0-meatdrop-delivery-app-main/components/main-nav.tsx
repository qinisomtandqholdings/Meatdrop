"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Beef } from "lucide-react"

import { cn } from "@/lib/utils"

export function MainNav() {
  const pathname = usePathname()

  // Update the condition to hide on signup pages as well
  // Don't show the main nav on the login, forgot password, reset password, or signup pages
  if (
    pathname === "/login" ||
    pathname === "/forgot-password" ||
    pathname === "/reset-password" ||
    pathname?.startsWith("/signup")
  ) {
    return null
  }

  return (
    <div className="mr-4 flex">
      <Link href="/" className="mr-6 flex items-center space-x-2">
        <Beef className="h-6 w-6 text-primary" />
        <span className="hidden font-bold sm:inline-block">MeatDrop</span>
      </Link>
      <nav className="flex items-center space-x-6 text-sm font-medium">
        <Link
          href="/"
          className={cn(
            "transition-colors hover:text-gray-900",
            pathname === "/" ? "text-gray-900 font-medium" : "text-gray-600",
          )}
        >
          Dashboard
        </Link>
        <Link
          href="/orders"
          className={cn(
            "transition-colors hover:text-gray-900",
            pathname?.startsWith("/orders") ? "text-gray-900 font-medium" : "text-gray-600",
          )}
        >
          Orders
        </Link>
        <Link
          href="/inventory"
          className={cn(
            "transition-colors hover:text-gray-900",
            pathname?.startsWith("/inventory") ? "text-gray-900 font-medium" : "text-gray-600",
          )}
        >
          Inventory
        </Link>
        <Link
          href="/deliveries"
          className={cn(
            "transition-colors hover:text-gray-900",
            pathname?.startsWith("/deliveries") ? "text-gray-900 font-medium" : "text-gray-600",
          )}
        >
          Deliveries
        </Link>
        <Link
          href="/customers"
          className={cn(
            "transition-colors hover:text-gray-900",
            pathname?.startsWith("/customers") ? "text-gray-900 font-medium" : "text-gray-600",
          )}
        >
          Customers
        </Link>
        <Link
          href="/reports"
          className={cn(
            "transition-colors hover:text-gray-900",
            pathname?.startsWith("/reports") ? "text-gray-900 font-medium" : "text-gray-600",
          )}
        >
          Reports
        </Link>
      </nav>
    </div>
  )
}
