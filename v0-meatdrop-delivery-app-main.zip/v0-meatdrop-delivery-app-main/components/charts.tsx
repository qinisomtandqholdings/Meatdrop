"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

// Simple mock chart components using canvas
export function BarChart({ title, description }: { title: string; description: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height)

    // Set up colors
    const barColors = [
      "#ef4444", // red
      "#f97316", // orange
      "#f59e0b", // amber
      "#84cc16", // lime
      "#10b981", // emerald
      "#06b6d4", // cyan
      "#3b82f6", // blue
    ]

    // Draw bars
    const barWidth = 40
    const spacing = 20
    const maxHeight = 150
    const data = [65, 85, 40, 95, 75, 55, 90]

    data.forEach((value, index) => {
      const x = 50 + index * (barWidth + spacing)
      const height = (value / 100) * maxHeight
      const y = 180 - height

      ctx.fillStyle = barColors[index % barColors.length]
      ctx.fillRect(x, y, barWidth, height)

      // Draw value on top of bar
      ctx.fillStyle = "#000"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.fillText(value.toString(), x + barWidth / 2, y - 5)

      // Draw label below bar
      ctx.fillText(`Day ${index + 1}`, x + barWidth / 2, 200)
    })

    // Draw axes
    ctx.beginPath()
    ctx.moveTo(40, 20)
    ctx.lineTo(40, 180)
    ctx.lineTo(400, 180)
    ctx.strokeStyle = "#888"
    ctx.stroke()
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription className="text-gray-700">{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="w-full overflow-x-auto">
          <canvas ref={canvasRef} width={450} height={220} />
        </div>
      </CardContent>
    </Card>
  )
}

export function LineChart({ title, description }: { title: string; description: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height)

    // Draw line chart
    const data = [30, 50, 45, 70, 65, 80, 90]
    const width = 400
    const height = 160
    const padding = 40
    const maxValue = Math.max(...data)

    // Draw axes
    ctx.beginPath()
    ctx.moveTo(padding, padding)
    ctx.lineTo(padding, height + padding)
    ctx.lineTo(width + padding, height + padding)
    ctx.strokeStyle = "#888"
    ctx.stroke()

    // Draw line
    ctx.beginPath()
    ctx.moveTo(padding, height + padding - (data[0] / maxValue) * height)

    for (let i = 1; i < data.length; i++) {
      const x = padding + (i / (data.length - 1)) * width
      const y = height + padding - (data[i] / maxValue) * height
      ctx.lineTo(x, y)
    }

    ctx.strokeStyle = "#3b82f6"
    ctx.lineWidth = 3
    ctx.stroke()

    // Draw points
    for (let i = 0; i < data.length; i++) {
      const x = padding + (i / (data.length - 1)) * width
      const y = height + padding - (data[i] / maxValue) * height

      ctx.beginPath()
      ctx.arc(x, y, 5, 0, Math.PI * 2)
      ctx.fillStyle = "#3b82f6"
      ctx.fill()

      // Draw value above point
      ctx.fillStyle = "#000"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.fillText(data[i].toString(), x, y - 10)
    }

    // Draw labels
    for (let i = 0; i < data.length; i++) {
      const x = padding + (i / (data.length - 1)) * width
      ctx.fillStyle = "#000"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.fillText(`Week ${i + 1}`, x, height + padding + 20)
    }
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription className="text-gray-700">{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="w-full overflow-x-auto">
          <canvas ref={canvasRef} width={450} height={220} />
        </div>
      </CardContent>
    </Card>
  )
}

export function PieChart({ title, description }: { title: string; description: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height)

    // Data for pie chart
    const data = [35, 25, 20, 15, 5]
    const labels = ["Beef", "Pork", "Poultry", "Lamb", "Other"]
    const colors = ["#ef4444", "#f97316", "#f59e0b", "#84cc16", "#3b82f6"]

    // Draw pie chart
    const centerX = canvasRef.current.width / 2
    const centerY = canvasRef.current.height / 2
    const radius = 80

    let startAngle = 0
    let endAngle = 0
    const total = data.reduce((sum, value) => sum + value, 0)

    // Draw legend
    const legendX = centerX + radius + 20
    const legendY = centerY - (labels.length * 20) / 2

    for (let i = 0; i < data.length; i++) {
      // Calculate angles for pie slice
      startAngle = endAngle
      endAngle = startAngle + (data[i] / total) * (Math.PI * 2)

      // Draw pie slice
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, startAngle, endAngle)
      ctx.closePath()
      ctx.fillStyle = colors[i]
      ctx.fill()

      // Draw percentage in slice
      const sliceAngle = startAngle + (endAngle - startAngle) / 2
      const percentageX = centerX + Math.cos(sliceAngle) * (radius * 0.6)
      const percentageY = centerY + Math.sin(sliceAngle) * (radius * 0.6)

      ctx.fillStyle = "#fff"
      ctx.font = "bold 12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(`${Math.round((data[i] / total) * 100)}%`, percentageX, percentageY)

      // Draw legend item
      ctx.fillStyle = colors[i]
      ctx.fillRect(legendX, legendY + i * 20, 15, 15)

      ctx.fillStyle = "#000"
      ctx.font = "12px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "middle"
      ctx.fillText(`${labels[i]} (${data[i]}%)`, legendX + 25, legendY + i * 20 + 7.5)
    }
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription className="text-gray-700">{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="w-full overflow-x-auto">
          <canvas ref={canvasRef} width={450} height={220} />
        </div>
      </CardContent>
    </Card>
  )
}
