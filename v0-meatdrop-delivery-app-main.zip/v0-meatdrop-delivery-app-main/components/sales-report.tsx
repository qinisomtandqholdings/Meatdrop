"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { LineChart, PieChart } from "@/components/charts"

// Sample sales data
const salesData = [
  {
    id: "ORD-1234",
    customer: "John Smith",
    date: "2023-06-20",
    items: ["Ribeye Steak (2kg)", "Ground Beef (1kg)"],
    total: 899.99,
    status: "Delivered",
  },
  {
    id: "ORD-1233",
    customer: "Sarah Johnson",
    date: "2023-06-19",
    items: ["Pork Chops (1kg)", "Chicken Breast (2kg)"],
    total: 675.0,
    status: "Delivered",
  },
  {
    id: "ORD-1232",
    customer: "Michael Brown",
    date: "2023-06-18",
    items: ["Lamb Rack (1.5kg)", "Sausages (1kg)"],
    total: 1127.5,
    status: "Delivered",
  },
  {
    id: "ORD-1231",
    customer: "Emily Davis",
    date: "2023-06-17",
    items: ["T-Bone Steak (1kg)", "Beef Brisket (2kg)"],
    total: 952.5,
    status: "Delivered",
  },
  {
    id: "ORD-1230",
    customer: "Robert Wilson",
    date: "2023-06-16",
    items: ["Chicken Thighs (2kg)", "Pork Belly (1kg)"],
    total: 785.25,
    status: "Delivered",
  },
  {
    id: "ORD-1229",
    customer: "Jennifer Taylor",
    date: "2023-06-15",
    items: ["Ground Beef (3kg)", "Ribeye Steak (1kg)"],
    total: 1099.75,
    status: "Delivered",
  },
  {
    id: "ORD-1228",
    customer: "David Martinez",
    date: "2023-06-14",
    items: ["Lamb Chops (2kg)", "Chicken Breast (1kg)"],
    total: 1245.5,
    status: "Delivered",
  },
]

export function SalesReport() {
  // Calculate sales statistics
  const totalSales = salesData.reduce((sum, sale) => sum + sale.total, 0)
  const averageOrderValue = totalSales / salesData.length
  const totalOrders = salesData.length

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R{totalSales.toFixed(2)}</div>
            <p className="text-xs text-gray-600">For the selected period</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalOrders}</div>
            <p className="text-xs text-gray-600">Average {(totalOrders / 7).toFixed(1)} orders per day</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Average Order Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R{averageOrderValue.toFixed(2)}</div>
            <p className="text-xs text-gray-600">+5.2% from previous period</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Top Product</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Ribeye Steak</div>
            <p className="text-xs text-gray-600">Appears in 28% of orders</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <LineChart title="Sales Trend" description="Daily sales for the selected period" />
        <PieChart title="Sales by Category" description="Percentage of sales by meat category" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Sales Details</CardTitle>
          <CardDescription className="text-gray-700">Order details for the selected period</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-black">Order ID</TableHead>
                <TableHead className="text-black">Customer</TableHead>
                <TableHead className="text-black">Date</TableHead>
                <TableHead className="text-black">Items</TableHead>
                <TableHead className="text-black">Total</TableHead>
                <TableHead className="text-black">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {salesData.map((sale) => (
                <TableRow key={sale.id}>
                  <TableCell className="font-medium text-black">{sale.id}</TableCell>
                  <TableCell className="text-black">{sale.customer}</TableCell>
                  <TableCell className="text-black">{sale.date}</TableCell>
                  <TableCell className="text-black">{sale.items.join(", ")}</TableCell>
                  <TableCell className="text-black">R{sale.total.toFixed(2)}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{sale.status}</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
