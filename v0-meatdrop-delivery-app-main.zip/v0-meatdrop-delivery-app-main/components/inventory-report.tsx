"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { BarChart, PieChart } from "@/components/charts"

export function InventoryReport() {
  const [inventory, setInventory] = useState<any[]>([])

  // Load inventory data
  useEffect(() => {
    const savedInventory = localStorage.getItem("meatdrop-inventory")
    if (savedInventory) {
      try {
        setInventory(JSON.parse(savedInventory))
      } catch (e) {
        console.error("Failed to parse saved inventory", e)
      }
    }
  }, [])

  // Calculate inventory statistics
  const totalItems = inventory.length
  const totalStock = inventory.reduce((sum, item) => sum + item.stock, 0)
  const totalValue = inventory.reduce((sum, item) => sum + item.stock * item.price, 0)
  const lowStockItems = inventory.filter((item) => item.status === "Low").length

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalItems}</div>
            <p className="text-xs text-gray-600">
              Across{" "}
              {
                inventory.reduce((acc, item) => (acc.includes(item.category) ? acc : [...acc, item.category]), [])
                  .length
              }{" "}
              categories
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Stock</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStock.toFixed(1)} kg</div>
            <p className="text-xs text-gray-600">Average {(totalStock / totalItems).toFixed(1)} kg per product</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Inventory Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R{totalValue.toFixed(2)}</div>
            <p className="text-xs text-gray-600">Based on current prices</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{lowStockItems}</div>
            <p className="text-xs text-gray-600">
              {Math.round((lowStockItems / totalItems) * 100)}% of inventory needs restocking
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <BarChart title="Stock Levels by Product" description="Current stock levels for top products" />
        <PieChart title="Inventory Distribution" description="Percentage of inventory by category" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Inventory Details</CardTitle>
          <CardDescription className="text-gray-700">Complete inventory with stock levels and values</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-black">Product</TableHead>
                <TableHead className="text-black">Category</TableHead>
                <TableHead className="text-black">Current Stock</TableHead>
                <TableHead className="text-black">Stock Level</TableHead>
                <TableHead className="text-black">Price/kg</TableHead>
                <TableHead className="text-black">Value</TableHead>
                <TableHead className="text-black">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {inventory.map((product) => (
                <TableRow key={product.id}>
                  <TableCell className="font-medium text-black">{product.name}</TableCell>
                  <TableCell className="text-black">{product.category}</TableCell>
                  <TableCell className="text-black">{product.stock} kg</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={(product.stock / product.maxStock) * 100} className="h-2 w-[100px]" />
                      <span className="text-xs text-black">
                        {Math.round((product.stock / product.maxStock) * 100)}%
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-black">R{product.price.toFixed(2)}</TableCell>
                  <TableCell className="text-black">R{(product.stock * product.price).toFixed(2)}</TableCell>
                  <TableCell>
                    <Badge
                      variant={product.status === "Low" ? "destructive" : "default"}
                      className={product.status === "Good" ? "bg-green-700 hover:bg-green-800" : ""}
                    >
                      {product.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
