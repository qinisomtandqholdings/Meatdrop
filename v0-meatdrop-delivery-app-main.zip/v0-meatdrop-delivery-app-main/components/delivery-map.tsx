"use client"

import { useEffect, useState } from "react"
import { Truck } from "lucide-react"

export function DeliveryMap() {
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  if (!isClient) {
    return <div className="flex items-center justify-center h-full">Loading map...</div>
  }

  return (
    <div className="relative h-full w-full bg-muted rounded-md overflow-hidden">
      {/* This would be replaced with an actual map integration */}
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=300&width=500')] bg-cover bg-center opacity-50"></div>

      {/* Placeholder for delivery vehicles */}
      <div className="absolute top-1/4 left-1/3 bg-primary/20 p-1 rounded-full">
        <div className="bg-primary text-primary-foreground p-1 rounded-full">
          <Truck className="h-4 w-4" />
        </div>
      </div>

      <div className="absolute top-2/3 right-1/4 bg-primary/20 p-1 rounded-full">
        <div className="bg-primary text-primary-foreground p-1 rounded-full">
          <Truck className="h-4 w-4" />
        </div>
      </div>

      <div className="absolute bottom-1/4 left-1/2 bg-primary/20 p-1 rounded-full">
        <div className="bg-primary text-primary-foreground p-1 rounded-full">
          <Truck className="h-4 w-4" />
        </div>
      </div>

      <div className="absolute inset-0 flex items-center justify-center">
        <div className="bg-background/80 px-4 py-2 rounded-md text-sm">Live map integration would appear here</div>
      </div>
    </div>
  )
}
