"use client"

import type React from "react"

import { useState } from "react"
import { MeatdropContext } from "./notifications"

export function MeatdropProvider({ children }: { children: React.ReactNode }) {
  const [pendingOrders, setPendingOrders] = useState<any[]>([])
  const [processedOrders, setProcessedOrders] = useState<string[]>([])
  const [inventoryUpdates, setInventoryUpdates] = useState<{ productId: number; name: string; change: number }[]>([])

  const clearInventoryUpdate = (productId: number) => {
    setInventoryUpdates((prev) => prev.filter((update) => update.productId !== productId))
  }

  return (
    <MeatdropContext.Provider
      value={{
        pendingOrders,
        setPendingOrders,
        processedOrders,
        setProcessedOrders,
        inventoryUpdates,
        setInventoryUpdates,
        clearInventoryUpdate,
      }}
    >
      {children}
    </MeatdropContext.Provider>
  )
}
