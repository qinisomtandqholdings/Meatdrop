"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useRouter } from "next/navigation"

// Sample incoming orders for demonstration
const initialOrders = [
  {
    id: "ORD-5678",
    customer: "John Smith",
    items: [{ name: "Ribeye Steak", quantity: 1, unit: "kg", productId: 1 }],
    total: "R299.99",
    time: "Just now",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: "ORD-5677",
    customer: "Sarah Johnson",
    items: [
      { name: "T-Bone Steak", quantity: 1.5, unit: "kg", productId: 7 },
      { name: "Ground Beef", quantity: 1, unit: "kg", productId: 5 },
    ],
    total: "R524.99",
    time: "5 minutes ago",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: "ORD-5676",
    customer: "Michael Brown",
    items: [{ name: "Sirloin Steak", quantity: 2, unit: "kg", productId: 3 }],
    total: "R559.98",
    time: "15 minutes ago",
    avatar: "/placeholder.svg?height=32&width=32",
  },
]

// Create a context to share order and inventory state across components
import { createContext, useContext } from "react"

export type OrderItem = {
  name: string
  quantity: number
  unit: string
  productId: number
}

export type Order = {
  id: string
  customer: string
  items: OrderItem[]
  total: string
  time: string
  avatar: string
}

type MeatdropContextType = {
  pendingOrders: Order[]
  setPendingOrders: React.Dispatch<React.SetStateAction<Order[]>>
  processedOrders: string[]
  setProcessedOrders: React.Dispatch<React.SetStateAction<string[]>>
  inventoryUpdates: { productId: number; name: string; change: number }[]
  setInventoryUpdates: React.Dispatch<React.SetStateAction<{ productId: number; name: string; change: number }[]>>
  clearInventoryUpdate: (productId: number) => void
}

export const MeatdropContext = createContext<MeatdropContextType>({
  pendingOrders: [],
  setPendingOrders: () => {},
  processedOrders: [],
  setProcessedOrders: () => {},
  inventoryUpdates: [],
  setInventoryUpdates: () => {},
  clearInventoryUpdate: () => {},
})

export const useMeatdrop = () => useContext(MeatdropContext)

export function Notifications() {
  const router = useRouter()
  const { pendingOrders, setPendingOrders, processedOrders } = useMeatdrop()
  const [unreadCount, setUnreadCount] = useState(0)
  const [isOpen, setIsOpen] = useState(false)

  // Initialize with existing orders
  useEffect(() => {
    if (pendingOrders.length === 0) {
      setPendingOrders(initialOrders)
    }
    setUnreadCount(pendingOrders.length)
  }, [pendingOrders.length, setPendingOrders])

  // Simulate a new order coming in after 30 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      const newOrder = {
        id: `ORD-${5675 + Math.floor(Math.random() * 10)}`,
        customer: "Emily Davis",
        items: [
          { name: "Fillet Steak", quantity: 1, unit: "kg", productId: 3 },
          { name: "Pork Sausages", quantity: 0.5, unit: "kg", productId: 6 },
        ],
        total: "R449.99",
        time: "Just now",
        avatar: "/placeholder.svg?height=32&width=32",
      }

      setPendingOrders((prev) => [newOrder, ...prev.filter((order) => !processedOrders.includes(order.id))])
      setUnreadCount((prev) => prev + 1)
    }, 30000)

    return () => clearTimeout(timer)
  }, [processedOrders, setPendingOrders])

  const handleOrderClick = (orderId: string) => {
    // Navigate to the order simulation page
    router.push(`/orders/simulate?id=${orderId}`)
    setIsOpen(false)
  }

  const handleOpenChange = (open: boolean) => {
    setIsOpen(open)
    if (open) {
      // Mark notifications as read when opened
      setUnreadCount(0)
    }
  }

  // Filter out processed orders from the display
  const displayOrders = pendingOrders.filter((order) => !processedOrders.includes(order.id))

  return (
    <DropdownMenu open={isOpen} onOpenChange={handleOpenChange}>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className="relative">
          <Bell className="h-4 w-4" />
          {unreadCount > 0 && (
            <Badge
              className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
              variant="destructive"
            >
              {unreadCount}
            </Badge>
          )}
          <span className="sr-only">Notifications</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80" align="end">
        <DropdownMenuLabel>Incoming Orders</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {displayOrders.length === 0 ? (
          <div className="py-2 px-4 text-center text-sm text-muted-foreground">No new orders</div>
        ) : (
          displayOrders.map((order) => (
            <DropdownMenuItem key={order.id} className="cursor-pointer p-3" onClick={() => handleOrderClick(order.id)}>
              <div className="flex w-full items-start gap-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={order.avatar || "/placeholder.svg"} alt={order.customer} />
                  <AvatarFallback>{order.customer[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-black">{order.id}</p>
                    <span className="text-xs text-muted-foreground">{order.time}</span>
                  </div>
                  <p className="text-sm text-black">{order.customer}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {order.items.map((item) => `${item.name} (${item.quantity}${item.unit})`).join(", ")}
                  </p>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline">New Order</Badge>
                    <span className="text-sm font-medium text-black">{order.total}</span>
                  </div>
                </div>
              </div>
            </DropdownMenuItem>
          ))
        )}
        <DropdownMenuSeparator />
        <Button variant="ghost" className="w-full justify-center text-sm" onClick={() => router.push("/orders")}>
          View All Orders
        </Button>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
